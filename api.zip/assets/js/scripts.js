// مدیریت رویدادهای کلیک
$(document).ready(function() {
  $('.ajax-form').submit(function(e) {
    e.preventDefault();
    $.post($(this).attr('action'), $(this).serialize(), function(data) {
      alert(data.message);
    });
  });
});