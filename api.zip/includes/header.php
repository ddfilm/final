<?php
session_start();
require_once __DIR__ . '/functions.php'; // اطمینان حاصل کنید که functions.php در همین پوشه است
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
   <!-- استایل‌های اصلی -->
<link rel="stylesheet" href="/assets/css/styles.css">
<!-- فونت ایران سنس -->
<link rel="stylesheet" href="https://fontiran.com/css/fontiran.css">
<!-- اسکریپت‌ها -->
<script src="/assets/js/scripts.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داریک تست | Daric Test</title>
    <!-- فونت ایران سنس -->
    <link rel="stylesheet" href="https://fontiran.com/css/fontiran.css">
    <!-- استایل‌های اصلی -->
    <style>
        body {
            font-family: 'IRANSans', sans-serif;
            background-color: #1a1a1a; /* تم تیره */
            color: #ffffff; /* متن سفید */
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        /* استایل‌های بیشتر... */
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1 style="color: #9c27b0;">داریک تست</h1> <!-- رنگ بنفش -->
            <nav>
                <!-- منوهای سایت -->
            </nav>
        </div>
    </header>