<?php
/**
 * فوتر سایت داریک تست
 * شامل اسکریپت‌های پایانی، کپی‌رایت و اطلاعات تماس
 */
?>
<footer style="background-color: #333; padding: 20px 0; text-align: center; margin-top: 50px;">
    <div class="container">
        <!-- بخش اطلاعات تماس و لینک‌ها -->
        <p style="color: #ff9800;"> <!-- رنگ نارنجی -->
            <strong>داریک تست | Daric Test</strong><br>
            مسابقات آنلاین اطلاعات عمومی
        </p>
        <p style="color: #fff; font-size: 14px;">
            © <?= date('Y') ?> تمامی حقوق محفوظ است.
        </p>
    </div>
</footer>

<!-- اسکریپت‌های جاوااسکریپت -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
// اسکریپت‌های عمومی سایت
$(document).ready(function() {
    // کدهای جاوااسکریپت مشترک
});
</script>
</body>
</html>