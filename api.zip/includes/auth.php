<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// مدیریت لاگین کاربر
function handle_login($username, $password) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        return true;
    }
    return false;
}

// در functions.php
function register_user($username, $password) {
    $pdo = db_connect();
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    return $stmt->execute([$username, $hashed_password]);
}
?>