<?php
// اتصال به دیتابیس
function db_connect() {
    $host = 'localhost'; // یا آدرس سرور دیتابیس
    $dbname = 'pcekmkhd_daric'; // نام دیتابیس
    $username = 'pcekmkhd_daricuser'; // نام کاربری دیتابیس
    $password = 'y8Ty9W.wqOp?';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("اتصال به دیتابیس ناموفق بود: " . $e->getMessage());
    }
}

// در functions.php
function register_user($username, $password) {
    $pdo = db_connect();
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    return $stmt->execute([$username, $hashed_password]);
}

// بررسی لاگین کاربر
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// هش کردن رمز عبور
function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

// اعتبارسنجی نام کاربری
function validate_username($username) {
    return preg_match('/^[a-zA-Z0-9_]+$/', $username);
}

// ریدایرکت کاربر
function redirect($url) {
    header("Location: $url");
    exit();
}

// نمایش خطاها
function display_error($error) {
    return '<div class="error-message">' . htmlspecialchars($error) . '</div>';
}

// جلوگیری از حملات XSS
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
?>