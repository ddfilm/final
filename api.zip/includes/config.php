<?php
// تنظیمات دیتابیس
define('DB_HOST', 'localhost');
define('DB_NAME', 'pcekmkhd_daric');
define('DB_USER', 'pcekmkhd_daricuser');
define('DB_PASS', 'y8Ty9W.wqOp?'); // تغییر دهید!

// تنظیمات سایت
define('SITE_NAME', 'داریک تست');
define('BASE_URL', 'https://yourdomain.com'); // آدرس سایت شما
?>