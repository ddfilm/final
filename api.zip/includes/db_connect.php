<?php
$host = 'localhost';
$dbname = 'pcekmkhd_daricdb';
$username = 'pcekmkhd_daricuser';
$password = 'y8Ty9W.wqOp?';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // اصلاح شده
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC); // اصلاح شده
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>