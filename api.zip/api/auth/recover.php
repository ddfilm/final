<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'password' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $color = $_POST['recover_color'];
    $flower = $_POST['recover_flower'];
    $city = $_POST['recover_city'];
    
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = ? AND security_color = ? AND security_flower = ? AND security_city = ?");
    $stmt->execute([$username, $color, $flower, $city]);
    $user = $stmt->fetch();
    
    if ($user) {
        // ایجاد رمز عبور موقت
        $temp_password = bin2hex(random_bytes(4));
        $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);
        
        // آپدیت رمز عبور کاربر
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed_password, $user['id']]);
        
        $response['success'] = true;
        $response['password'] = $temp_password;
    } else {
        $response['message'] = 'پاسخ‌های ارائه شده با اطلاعات حساب مطابقت ندارند';
    }
}

echo json_encode($response);
?>