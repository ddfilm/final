<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];
    $security_color = $_POST['security_color'];
    $security_flower = $_POST['security_flower'];
    $security_city = $_POST['security_city'];
    
    // اعتبارسنجی
    if (empty($username) || empty($password) || empty($password_confirm)) {
        $response['message'] = 'لطفاً تمام فیلدها را پر کنید';
    } elseif (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
        $response['message'] = 'نام کاربری فقط می‌تواند شامل حروف انگلیسی و اعداد باشد';
    } elseif ($password !== $password_confirm) {
        $response['message'] = 'رمز عبور و تکرار آن مطابقت ندارند';
    } elseif (strlen($password) < 6) {
        $response['message'] = 'رمز عبور باید حداقل 6 کاراکتر باشد';
    } else {
        // بررسی تکراری نبودن نام کاربری
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->rowCount() > 0) {
            $response['message'] = 'این نام کاربری قبلاً ثبت شده است';
        } else {
            // ثبت کاربر جدید
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $pdo->prepare("INSERT INTO users (username, password, security_color, security_flower, security_city) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $security_color, $security_flower, $security_city]);
            
            $response['success'] = true;
            $response['message'] = 'ثبت نام با موفقیت انجام شد';
        }
    }
}

echo json_encode($response);
?>