<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['available' => false];

if (isset($_POST['username'])) {
    $username = $_POST['username'];
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    $response['available'] = $stmt->rowCount() === 0;
}

echo json_encode($response);
?>