<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $team_id = $_POST['team_id'];
    $password = $_POST['password'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی رمز عبور
        $user_stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $user_stmt->execute([$admin_id]);
        $user = $user_stmt->fetch();
        
        if (!password_verify($password, $user['password'])) {
            throw new Exception('رمز عبور اشتباه است');
        }
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("SELECT id, logo FROM teams WHERE id = ? AND admin_id = ?");
        $admin_stmt->execute([$team_id, $admin_id]);
        $team = $admin_stmt->fetch();
        
        if (!$team) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // حذف لوگو (اگر وجود دارد)
        if ($team['logo']) {
            $upload_dir = '../../assets/images/teams/';
            if (file_exists($upload_dir . $team['logo'])) {
                unlink($upload_dir . $team['logo']);
            }
        }
        
        // ارسال پیام به اعضا
        $members = $pdo->prepare("
            SELECT user_id 
            FROM team_members 
            WHERE team_id = ? AND is_active = 1
        ")->execute([$team_id])->fetchAll();
        
        foreach ($members as $member) {
            $message_stmt = $pdo->prepare("
                INSERT INTO messages 
                (sender_id, receiver_type, receiver_id, subject, message) 
                VALUES (?, 'user', ?, ?, ?)
            ");
            $message_stmt->execute([
                $admin_id,
                $member['user_id'],
                'انحلال اکیپ ' . $team['name'],
                'اکیپ ' . $team['name'] . ' توسط ادمین منحل شده است.'
            ]);
        }
        
        // غیرفعال کردن اعضا
        $pdo->prepare("
            UPDATE team_members 
            SET is_active = 0 
            WHERE team_id = ?
        ")->execute([$team_id]);
        
        // حذف اکیپ
        $pdo->prepare("DELETE FROM teams WHERE id = ?")->execute([$team_id]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'اکیپ با موفقیت منحل شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>