<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $team_id = $_POST['team_id'];
    $team_name = $_POST['team_name'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("SELECT id, logo FROM teams WHERE id = ? AND admin_id = ?");
        $admin_stmt->execute([$team_id, $admin_id]);
        $team = $admin_stmt->fetch();
        
        if (!$team) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // بررسی تغییر لوگو
        $logo_changed = false;
        $new_logo = $team['logo'];
        
        if (isset($_FILES['team_logo']) && $_FILES['team_logo']['error'] === UPLOAD_ERR_OK) {
            // کسر هزینه برای تغییر لوگو
            $user_balance = $pdo->prepare("SELECT daric_balance FROM users WHERE id = ?")
                ->execute([$admin_id])->fetchColumn();
                
            if ($user_balance < 100) {
                throw new Exception('برای تغییر لوگو حداقل 100 داریک نیاز دارید');
            }
            
            // آپلود لوگوی جدید
            $upload_dir = '../../assets/images/teams/';
            $new_logo = uniqid() . '_' . basename($_FILES['team_logo']['name']);
            move_uploaded_file($_FILES['team_logo']['tmp_name'], $upload_dir . $new_logo);
            
            // حذف لوگوی قدیمی (اگر وجود دارد)
            if ($team['logo'] && file_exists($upload_dir . $team['logo'])) {
                unlink($upload_dir . $team['logo']);
            }
            
            // کسر هزینه از حساب ادمین
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - 100 WHERE id = ?")
                ->execute([$admin_id]);
                
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, 100, 'spend', 'تغییر لوگوی اکیپ', ?, 'team')
            ");
            $transaction_stmt->execute([$admin_id, $team_id]);
            
            $logo_changed = true;
        }
        
        // به‌روزرسانی اطلاعات اکیپ
        $update_stmt = $pdo->prepare("
            UPDATE teams 
            SET name = ?, logo = ?
            WHERE id = ?
        ");
        $update_stmt->execute([$team_name, $new_logo, $team_id]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'اطلاعات اکیپ با موفقیت به‌روزرسانی شد';
        if ($logo_changed) {
            $response['message'] .= ' (100 داریک برای تغییر لوگو کسر شد)';
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        
        // حذف فایل آپلود شده در صورت خطا
        if (isset($new_logo) {
            unlink($upload_dir . $new_logo);
        }
        
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>