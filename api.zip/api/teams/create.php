<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $team_name = $_POST['team_name'];
    
    // بررسی موجودی کاربر
    $balance_stmt = $pdo->prepare("SELECT daric_balance FROM users WHERE id = ?");
    $balance_stmt->execute([$user_id]);
    $user_balance = $balance_stmt->fetchColumn();
    
    if ($user_balance < 500) {
        $response['message'] = 'موجودی داریک شما برای ساخت اکیپ کافی نیست (حداقل 500 داریک مورد نیاز است)';
    } else {
        try {
            $pdo->beginTransaction();
            
            // آپلود لوگو (اگر وجود دارد)
            $logo_name = null;
            if (isset($_FILES['team_logo']) && $_FILES['team_logo']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../../assets/images/teams/';
                $logo_name = uniqid() . '_' . basename($_FILES['team_logo']['name']);
                move_uploaded_file($_FILES['team_logo']['tmp_name'], $upload_dir . $logo_name);
            }
            
            // ایجاد اکیپ جدید
            $team_stmt = $pdo->prepare("
                INSERT INTO teams (name, logo, admin_id) 
                VALUES (?, ?, ?)
            ");
            $team_stmt->execute([$team_name, $logo_name, $user_id]);
            $team_id = $pdo->lastInsertId();
            
            // اضافه کردن کاربر به اکیپ
            $member_stmt = $pdo->prepare("
                INSERT INTO team_members (team_id, user_id) 
                VALUES (?, ?)
            ");
            $member_stmt->execute([$team_id, $user_id]);
            
            // کسر هزینه از حساب کاربر
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - 500 WHERE id = ?")->execute([$user_id]);
            
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, 500, 'spend', 'ساخت اکیپ جدید', ?, 'team')
            ");
            $transaction_stmt->execute([$user_id, $team_id]);
            
            $pdo->commit();
            
            $response['success'] = true;
            $response['message'] = 'اکیپ با موفقیت ایجاد شد!';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $response['message'] = 'خطا در ایجاد اکیپ: ' . $e->getMessage();
            
            // حذف فایل آپلود شده در صورت خطا
            if ($logo_name && file_exists($upload_dir . $logo_name)) {
                unlink($upload_dir . $logo_name);
            }
        }
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>