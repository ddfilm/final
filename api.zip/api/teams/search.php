<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['name'])) {
    $name = '%' . $_GET['name'] . '%';
    $exclude = isset($_GET['exclude']) ? intval($_GET['exclude']) : 0;
    
    $stmt = $pdo->prepare("
        SELECT t.id, t.name, t.logo, 
               COUNT(tm.user_id) as member_count
        FROM teams t
        LEFT JOIN team_members tm ON t.id = tm.team_id AND tm.is_active = 1
        WHERE t.name LIKE ? AND t.id != ?
        GROUP BY t.id
        LIMIT 10
    ");
    $stmt->execute([$name, $exclude]);
    $response = $stmt->fetchAll();
}

echo json_encode($response);
?>