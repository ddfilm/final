<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $user_id = $_POST['user_id'];
    $team_id = $_POST['team_id'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("SELECT id FROM teams WHERE id = ? AND admin_id = ?");
        $admin_stmt->execute([$team_id, $admin_id]);
        
        if ($admin_stmt->rowCount() === 0) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // بررسی آیا کاربر عضو اکیپ است
        $member_stmt = $pdo->prepare("
            SELECT id 
            FROM team_members 
            WHERE team_id = ? AND user_id = ? AND is_active = 1
        ");
        $member_stmt->execute([$team_id, $user_id]);
        
        if ($member_stmt->rowCount() === 0) {
            throw new Exception('این کاربر عضو اکیپ شما نیست');
        }
        
        // اخراج کاربر
        $pdo->prepare("
            UPDATE team_members 
            SET is_active = 0 
            WHERE team_id = ? AND user_id = ?
        ")->execute([$team_id, $user_id]);
        
        // ارسال پیام به کاربر
        $team_name = $pdo->prepare("SELECT name FROM teams WHERE id = ?")
            ->execute([$team_id])->fetchColumn();
            
        $message_stmt = $pdo->prepare("
            INSERT INTO messages 
            (sender_id, receiver_type, receiver_id, subject, message) 
            VALUES (?, 'user', ?, ?, ?)
        ");
        $message_stmt->execute([
            $admin_id,
            $user_id,
            'اخراج از اکیپ ' . $team_name,
            'شما توسط ادمین از اکیپ ' . $team_name . ' اخراج شده‌اید.'
        ]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'کاربر با موفقیت از اکیپ اخراج شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>