<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $username = $_POST['username'];
    $team_id = $_POST['team_id'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("SELECT id FROM teams WHERE id = ? AND admin_id = ?");
        $admin_stmt->execute([$team_id, $admin_id]);
        
        if ($admin_stmt->rowCount() === 0) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // بررسی تعداد اعضای اکیپ
        $member_count = $pdo->prepare("
            SELECT COUNT(*) 
            FROM team_members 
            WHERE team_id = ? AND is_active = 1
        ")->execute([$team_id])->fetchColumn();
        
        if ($member_count >= 20) {
            throw new Exception('اکیپ شما به حداکثر تعداد اعضا رسیده است');
        }
        
        // پیدا کردن کاربر مورد نظر
        $user_stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $user_stmt->execute([$username]);
        $user = $user_stmt->fetch();
        
        if (!$user) {
            throw new Exception('کاربر مورد نظر یافت نشد');
        }
        
        // بررسی آیا کاربر قبلاً عضو اکیپ است
        $member_stmt = $pdo->prepare("
            SELECT id 
            FROM team_members 
            WHERE team_id = ? AND user_id = ? AND is_active = 1
        ");
        $member_stmt->execute([$team_id, $user['id']]);
        
        if ($member_stmt->rowCount() > 0) {
            throw new Exception('این کاربر هم اکنون عضو اکیپ شماست');
        }
        
        // بررسی آیا قبلاً دعوت شده است
        $invite_stmt = $pdo->prepare("
            SELECT id 
            FROM messages 
            WHERE sender_id = ? AND receiver_id = ? 
            AND subject LIKE 'دعوت به اکیپ%' AND is_read = 0
        ");
        $invite_stmt->execute([$admin_id, $user['id']]);
        
        if ($invite_stmt->rowCount() > 0) {
            throw new Exception('قبلاً به این کاربر دعوتنامه ارسال کرده‌اید');
        }
        
        // کسر هزینه از حساب ادمین
        $pdo->prepare("UPDATE users SET daric_balance = daric_balance - 50 WHERE id = ?")
            ->execute([$admin_id]);
        
        // ثبت تراکنش
        $transaction_stmt = $pdo->prepare("
            INSERT INTO daric_transactions 
            (user_id, amount, type, description, related_id, related_type) 
            VALUES (?, 50, 'spend', 'ارسال دعوتنامه به اکیپ', ?, 'team')
        ");
        $transaction_stmt->execute([$admin_id, $team_id]);
        
        // ارسال پیام دعوت
        $team_name = $pdo->prepare("SELECT name FROM teams WHERE id = ?")
            ->execute([$team_id])->fetchColumn();
            
        $message_stmt = $pdo->prepare("
            INSERT INTO messages 
            (sender_id, receiver_type, receiver_id, subject, message) 
            VALUES (?, 'user', ?, ?, ?)
        ");
        $message_stmt->execute([
            $admin_id,
            $user['id'],
            'دعوت به اکیپ ' . $team_name,
            'شما توسط ادمین اکیپ ' . $team_name . ' به عضویت در این اکیپ دعوت شده‌اید.'
        ]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'دعوتنامه با موفقیت ارسال شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>