<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $challenge_id = $_POST['challenge_id'];
    $team_id = $_POST['team_id'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا چالش هنوز برای ثبت نام باز است
        $challenge_stmt = $pdo->prepare("
            SELECT id, start_date 
            FROM challenges 
            WHERE id = ? AND status = 'upcoming' AND start_date > CURDATE()
        ");
        $challenge_stmt->execute([$challenge_id]);
        $challenge = $challenge_stmt->fetch();
        
        if (!$challenge) {
            throw new Exception('زمان ثبت نام در این چالش به پایان رسیده است');
        }
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("
            SELECT id 
            FROM teams 
            WHERE id = ? AND admin_id = ?
        ");
        $admin_stmt->execute([$team_id, $admin_id]);
        
        if ($admin_stmt->rowCount() === 0) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // بررسی آیا اکیپ قبلاً ثبت نام کرده است
        $participation_stmt = $pdo->prepare("
            SELECT id 
            FROM challenge_participants 
            WHERE challenge_id = ? AND team_id = ?
        ");
        $participation_stmt->execute([$challenge_id, $team_id]);
        
        if ($participation_stmt->rowCount() > 0) {
            throw new Exception('اکیپ شما قبلاً در این چالش ثبت نام کرده است');
        }
        
        // محاسبه هزینه ثبت نام (100 داریک به ازای هر عضو)
        $member_count = $pdo->prepare("
            SELECT COUNT(*) 
            FROM team_members 
            WHERE team_id = ? AND is_active = 1
        ")->execute([$team_id])->fetchColumn();
        
        $cost = $member_count * 100;
        
        // بررسی موجودی اعضا
        $members = $pdo->prepare("
            SELECT u.id, u.username, u.daric_balance
            FROM team_members tm
            JOIN users u ON tm.user_id = u.id
            WHERE tm.team_id = ? AND tm.is_active = 1
        ")->execute([$team_id])->fetchAll();
        
        $share = ceil($cost / $member_count);
        $insufficient_members = [];
        
        foreach ($members as $member) {
            if ($member['daric_balance'] < $share) {
                $insufficient_members[] = $member['username'];
            }
        }
        
        if (!empty($insufficient_members)) {
            throw new Exception('اعضای زیر موجودی کافی ندارند: ' . implode(', ', $insufficient_members));
        }
        
        // کسر هزینه از حساب اعضا
        foreach ($members as $member) {
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - ? WHERE id = ?")
                ->execute([$share, $member['id']]);
                
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, ?, 'spend', 'هزینه ثبت نام چالش', ?, 'challenge')
            ");
            $transaction_stmt->execute([$member['id'], $share, $challenge_id]);
        }
        
        // ثبت نام اکیپ در چالش
        $register_stmt = $pdo->prepare("
            INSERT INTO challenge_participants 
            (challenge_id, team_id, cost) 
            VALUES (?, ?, ?)
        ");
        $register_stmt->execute([$challenge_id, $team_id, $cost]);
        
        // ارسال پیام به اعضا
        $team_name = $pdo->prepare("SELECT name FROM teams WHERE id = ?")
            ->execute([$team_id])->fetchColumn();
            
        $message = "اکیپ {$team_name} در چالش {$challenge['name']} ثبت نام کرد. هزینه ثبت نام به مبلغ {$share} داریک از حساب شما کسر شد.";
        
        foreach ($members as $member) {
            $message_stmt = $pdo->prepare("
                INSERT INTO messages 
                (sender_id, receiver_type, receiver_id, subject, message) 
                VALUES (?, 'user', ?, ?, ?)
            ");
            $message_stmt->execute([
                $admin_id,
                $member['id'],
                'ثبت نام در چالش',
                $message
            ]);
        }
        
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = 'ثبت نام با موفقیت انجام شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>