<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'team_avg' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $challenge_id = $_POST['challenge_id'];
    $team_id = $_POST['team_id'];
    $day_number = $_POST['day_number'];
    $score = $_POST['score'];
    $answered_questions = $_POST['answered_questions'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا چالش هنوز فعال است
        $challenge_stmt = $pdo->prepare("
            SELECT id, end_date 
            FROM challenges 
            WHERE id = ? AND status = 'ongoing' AND end_date >= CURDATE()
        ");
        $challenge_stmt->execute([$challenge_id]);
        $challenge = $challenge_stmt->fetch();
        
        if (!$challenge) {
            throw new Exception('زمان چالش به پایان رسیده است');
        }
        
        // بررسی آیا اکیپ در چالش ثبت نام کرده است
        $participation_stmt = $pdo->prepare("
            SELECT id 
            FROM challenge_participants 
            WHERE challenge_id = ? AND team_id = ?
        ");
        $participation_stmt->execute([$challenge_id, $team_id]);
        
        if ($participation_stmt->rowCount() === 0) {
            throw new Exception('اکیپ شما در این چالش ثبت نام نکرده است');
        }
        
        // بررسی آیا کاربر عضو اکیپ است
        $member_stmt = $pdo->prepare("
            SELECT id 
            FROM team_members 
            WHERE team_id = ? AND user_id = ? AND is_active = 1
        ");
        $member_stmt->execute([$team_id, $user_id]);
        
        if ($member_stmt->rowCount() === 0) {
            throw new Exception('شما عضو این اکیپ نیستید');
        }
        
        // بررسی آیا کاربر امروز قبلاً شرکت کرده است
        $played_stmt = $pdo->prepare("
            SELECT id 
            FROM daily_challenge_results 
            WHERE challenge_id = ? AND team_id = ? AND user_id = ? AND day_number = ?
        ");
        $played_stmt->execute([$challenge_id, $team_id, $user_id, $day_number]);
        
        if ($played_stmt->rowCount() > 0) {
            throw new Exception('شما امروز قبلاً در این چالش شرکت کرده‌اید');
        }
        
        // ذخیره نتایج کاربر
        $result_stmt = $pdo->prepare("
            INSERT INTO daily_challenge_results 
            (challenge_id, team_id, user_id, day_number, score, answered_questions) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $result_stmt->execute([$challenge_id, $team_id, $user_id, $day_number, $score, $answered_questions]);
        
        // محاسبه میانگین امتیاز تیم
        $avg_stmt = $pdo->prepare("
            SELECT AVG(score) as team_avg
            FROM daily_challenge_results
            WHERE challenge_id = ? AND team_id = ?
        ");
        $avg_stmt->execute([$challenge_id, $team_id]);
        $team_avg = $avg_stmt->fetchColumn();
        $response['team_avg'] = round($team_avg, 1);
        
        // اگر آخرین روز چالش است، نتایج نهایی را محاسبه کن
        $today = new DateTime();
        $end_date = new DateTime($challenge['end_date']);
        
        if ($today >= $end_date) {
            // به‌روزرسانی میانگین نهایی اکیپ
            $pdo->prepare("
                UPDATE challenge_participants 
                SET final_score = ?,
                    final_rank = (
                        SELECT position FROM (
                            SELECT team_id, ROW_NUMBER() OVER (ORDER BY AVG(score) DESC) as position
                            FROM daily_challenge_results
                            WHERE challenge_id = ?
                            GROUP BY team_id
                        ) as ranks
                        WHERE team_id = ?
                    )
                WHERE challenge_id = ? AND team_id = ?
            ")->execute([$team_avg, $challenge_id, $team_id, $challenge_id, $team_id]);
            
            // توزیع جوایز به 3 تیم برتر
            $top_teams = $pdo->prepare("
                SELECT cp.team_id, t.name, cp.final_rank
                FROM challenge_participants cp
                JOIN teams t ON cp.team_id = t.id
                WHERE cp.challenge_id = ?
                ORDER BY cp.final_rank
                LIMIT 3
            ")->execute([$challenge_id])->fetchAll();
            
            $rewards = [
                1 => 1000, // جایزه رتبه اول
                2 => 700,  // جایزه رتبه دوم
                3 => 500   // جایزه رتبه سوم
            ];
            
            foreach ($top_teams as $team) {
                $reward = $rewards[$team['final_rank']];
                $members = $pdo->prepare("
                    SELECT user_id 
                    FROM team_members 
                    WHERE team_id = ? AND is_active = 1
                ")->execute([$team['team_id']])->fetchAll();
                
                $reward_per_member = floor($reward / count($members));
                
                foreach ($members as $member) {
                    $pdo->prepare("UPDATE users SET daric_balance = daric_balance + ? WHERE id = ?")
                        ->execute([$reward_per_member, $member['user_id']]);
                        
                    // ثبت تراکنش
                    $transaction_stmt = $pdo->prepare("
                        INSERT INTO daric_transactions 
                        (user_id, amount, type, description, related_id, related_type) 
                        VALUES (?, ?, 'earn', 'جایزه چالش 7 روزه', ?, 'challenge')
                    ");
                    $transaction_stmt->execute([$member['user_id'], $reward_per_member, $challenge_id]);
                }
                
                // ارسال پیام به اعضای تیم برنده
                $message = "تبریک! اکیپ شما در چالش 7 روزه رتبه {$team['final_rank']} را کسب کرد و هر عضو {$reward_per_member} داریک جایزه دریافت کرد.";
                
                foreach ($members as $member) {
                    $message_stmt = $pdo->prepare("
                        INSERT INTO messages 
                        (sender_id, receiver_type, receiver_id, subject, message) 
                        VALUES (?, 'user', ?, ?, ?)
                    ");
                    $message_stmt->execute([
                        $user_id,
                        $member['user_id'],
                        'برنده چالش 7 روزه',
                        $message
                    ]);
                }
            }
            
            // تغییر وضعیت چالش به اتمام یافته
            $pdo->prepare("
                UPDATE challenges 
                SET status = 'completed'
                WHERE id = ?
            ")->execute([$challenge_id]);
        }
        
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = 'نتایج با موفقیت ذخیره شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>