<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $amount = intval($_POST['amount']);
    $description = $_POST['description'];
    
    // بررسی موجودی کاربر
    $balance_stmt = $pdo->prepare("SELECT daric_balance FROM users WHERE id = ?");
    $balance_stmt->execute([$user_id]);
    $user_balance = $balance_stmt->fetchColumn();
    
    if ($user_balance < $amount) {
        $response['message'] = 'موجودی داریک شما کافی نیست';
    } else {
        try {
            $pdo->beginTransaction();
            
            // کسر از حساب کاربر
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - ? WHERE id = ?")
                ->execute([$amount, $user_id]);
            
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description) 
                VALUES (?, ?, 'spend', ?)
            ");
            $transaction_stmt->execute([$user_id, $amount, $description]);
            
            $pdo->commit();
            
            $response['success'] = true;
            $response['message'] = 'عملیات با موفقیت انجام شد';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $response['message'] = 'خطا در انجام تراکنش: ' . $e->getMessage();
        }
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>