<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $sender_id = $_SESSION['user_id'];
    $receiver_type = $_POST['receiver_type'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // تعیین گیرنده بر اساس نوع
    $receiver_id = null;
    if ($receiver_type === 'admin') {
        $receiver_type = 'admin';
    } elseif ($receiver_type === 'team_member' || $receiver_type === 'user') {
        if (!empty($_POST['receiver_id'])) {
            $receiver_id = $_POST['receiver_id'];
        } else {
            $response['message'] = 'گیرنده پیام را انتخاب کنید';
            echo json_encode($response);
            exit();
        }
    }
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO messages 
            (sender_id, receiver_type, receiver_id, subject, message) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$sender_id, $receiver_type, $receiver_id, $subject, $message]);
        
        $response['success'] = true;
        $response['message'] = 'پیام با موفقیت ارسال شد.';
    } catch (PDOException $e) {
        $response['message'] = 'خطا در ارسال پیام: ' . $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>