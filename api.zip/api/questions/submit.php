<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $category_id = $_POST['category'];
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO questions 
            (category_id, question, option1, option2, option3, option4, correct_option, created_by) 
            VALUES (?, ?, ?, ?, ?, ?, 1, ?)
        ");
        $stmt->execute([$category_id, $question, $option1, $option2, $option3, $option4, $user_id]);
        
        $response['success'] = true;
        $response['message'] = 'سوال با موفقیت ثبت شد و پس از تایید، 100 داریک به حساب شما واریز خواهد شد.';
    } catch (PDOException $e) {
        $response['message'] = 'خطا در ثبت سوال: ' . $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>