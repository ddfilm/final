<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_SESSION['user_id']) && $_SESSION['user_id'] == 1) {
    $stmt = $pdo->query("
        SELECT id, name 
        FROM teams 
        ORDER BY name
    ");
    $response = $stmt->fetchAll();
}

echo json_encode($response);
?>