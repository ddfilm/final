<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id']) && $_SESSION['user_id'] == 1) {
    $sender_id = $_SESSION['user_id'];
    $receiver_type = $_POST['receiver_type'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $receiver_id = isset($_POST['receiver_id']) ? $_POST['receiver_id'] : null;
    
    try {
        $pdo->beginTransaction();
        
        if ($receiver_type === 'all_users') {
            // ارسال پیام به همه کاربران
            $users = $pdo->query("SELECT id FROM users")->fetchAll();
            
            foreach ($users as $user) {
                $stmt = $pdo->prepare("
                    INSERT INTO messages 
                    (sender_id, receiver_type, receiver_id, subject, message) 
                    VALUES (?, 'user', ?, ?, ?)
                ");
                $stmt->execute([$sender_id, $user['id'], $subject, $message]);
            }
            
            $response['message'] = 'پیام به همه کاربران ارسال شد';
        } elseif ($receiver_type === 'user' && $receiver_id) {
            // ارسال پیام به کاربر خاص
            $stmt = $pdo->prepare("
                INSERT INTO messages 
                (sender_id, receiver_type, receiver_id, subject, message) 
                VALUES (?, 'user', ?, ?, ?)
            ");
            $stmt->execute([$sender_id, $receiver_id, $subject, $message]);
            
            $response['message'] = 'پیام به کاربر مورد نظر ارسال شد';
        } elseif ($receiver_type === 'team' && $receiver_id) {
            // ارسال پیام به همه اعضای اکیپ
            $members = $pdo->prepare("
                SELECT user_id 
                FROM team_members 
                WHERE team_id = ? AND is_active = 1
            ")->execute([$receiver_id])->fetchAll();
            
            foreach ($members as $member) {
                $stmt = $pdo->prepare("
                    INSERT INTO messages 
                    (sender_id, receiver_type, receiver_id, subject, message) 
                    VALUES (?, 'user', ?, ?, ?)
                ");
                $stmt->execute([$sender_id, $member['user_id'], $subject, $message]);
            }
            
            $response['message'] = 'پیام به همه اعضای اکیپ ارسال شد';
        } else {
            throw new Exception('گیرنده پیام مشخص نشده است');
        }
        
        $pdo->commit();
        $response['success'] = true;
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'دسترسی غیرمجاز';
}

echo json_encode($response);
?>