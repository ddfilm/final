<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $admin_id = $_SESSION['user_id'];
    $team1_id = $_POST['team1_id'];
    $opponent = $_POST['opponent'];
    $cost = intval($_POST['cost']);
    
    // اعتبارسنجی هزینه
    if ($cost < 100 || $cost > 1000) {
        $response['message'] = 'هزینه کل کل باید بین 100 تا 1000 داریک باشد';
        echo json_encode($response);
        exit();
    }
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا کاربر ادمین اکیپ است
        $admin_stmt = $pdo->prepare("SELECT id FROM teams WHERE id = ? AND admin_id = ?");
        $admin_stmt->execute([$team1_id, $admin_id]);
        
        if ($admin_stmt->rowCount() === 0) {
            throw new Exception('شما اجازه این عمل را ندارید');
        }
        
        // پیدا کردن اکیپ مقابل
        $team2_stmt = $pdo->prepare("
            SELECT id, name, admin_id 
            FROM teams 
            WHERE (id = ? OR name LIKE ?) AND id != ?
            LIMIT 1
        ");
        $team2_stmt->execute([$opponent, '%' . $opponent . '%', $team1_id]);
        $team2 = $team2_stmt->fetch();
        
        if (!$team2) {
            throw new Exception('اکیپ مقابل یافت نشد');
        }
        
        // بررسی موجودی اعضای اکیپ
        $team1_members = $pdo->prepare("
            SELECT u.id, u.username, u.daric_balance
            FROM team_members tm
            JOIN users u ON tm.user_id = u.id
            WHERE tm.team_id = ? AND tm.is_active = 1
        ")->execute([$team1_id])->fetchAll();
        
        $team2_members = $pdo->prepare("
            SELECT u.id, u.username, u.daric_balance
            FROM team_members tm
            JOIN users u ON tm.user_id = u.id
            WHERE tm.team_id = ? AND tm.is_active = 1
        ")->execute([$team2['id']])->fetchAll();
        
        // محاسبه سهم هر عضو
        $share = ceil($cost / max(count($team1_members), count($team2_members)));
        
        // بررسی موجودی کافی اعضا
        $insufficient_members = [];
        
        foreach ($team1_members as $member) {
            if ($member['daric_balance'] < $share) {
                $insufficient_members[] = $member['username'];
            }
        }
        
        foreach ($team2_members as $member) {
            if ($member['daric_balance'] < $share) {
                $insufficient_members[] = $member['username'];
            }
        }
        
        if (!empty($insufficient_members)) {
            throw new Exception('اعضای زیر موجودی کافی ندارند: ' . implode(', ', $insufficient_members));
        }
        
        // ایجاد درخواست کل کل
        $duel_stmt = $pdo->prepare("
            INSERT INTO duels 
            (team1_id, team2_id, initiator_id, status, cost) 
            VALUES (?, ?, ?, 'pending', ?)
        ");
        $duel_stmt->execute([$team1_id, $team2['id'], $admin_id, $cost]);
        $duel_id = $pdo->lastInsertId();
        
        // ارسال پیام به ادمین اکیپ مقابل
        $team1_name = $pdo->prepare("SELECT name FROM teams WHERE id = ?")
            ->execute([$team1_id])->fetchColumn();
            
        $message_stmt = $pdo->prepare("
            INSERT INTO messages 
            (sender_id, receiver_type, receiver_id, subject, message) 
            VALUES (?, 'user', ?, ?, ?)
        ");
        $message_stmt->execute([
            $admin_id,
            $team2['admin_id'],
            'درخواست کل کل از ' . $team1_name,
            'اکیپ ' . $team1_name . ' برای شما درخواست کل کل با هزینه ' . $cost . ' داریک ارسال کرده است.'
        ]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'درخواست کل کل با موفقیت ارسال شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>