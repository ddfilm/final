<?php
// api/duels/accept.php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $duel_id = $_POST['duel_id'];
    
    try {
        $pdo->beginTransaction();
        
        // دریافت اطلاعات کل کل
        $duel_stmt = $pdo->prepare("
            SELECT d.*, t1.name as team1_name, t2.name as team2_name
            FROM duels d
            JOIN teams t1 ON d.team1_id = t1.id
            JOIN teams t2 ON d.team2_id = t2.id
            WHERE d.id = ? AND (t1.admin_id = ? OR t2.admin_id = ?)
        ");
        $duel_stmt->execute([$duel_id, $user_id, $user_id]);
        $duel = $duel_stmt->fetch();
        
        if (!$duel) {
            throw new Exception('درخواست کل کل یافت نشد یا شما اجازه این عمل را ندارید');
        }
        
        if ($duel['status'] != 'pending') {
            throw new Exception('این درخواست کل کل قبلاً پردازش شده است');
        }
        
        // بررسی اینکه آیا کاربر ادمین اکیپ مقابل است
        $is_team2_admin = ($duel['team2_id'] == $user_id);
        
        if (!$is_team2_admin) {
            throw new Exception('فقط ادمین اکیپ مقابل می‌تواند درخواست را قبول کند');
        }
        
        // بررسی موجودی اعضای هر دو اکیپ
        $team1_members = $pdo->prepare("
            SELECT u.id, u.username, u.daric_balance
            FROM team_members tm
            JOIN users u ON tm.user_id = u.id
            WHERE tm.team_id = ? AND tm.is_active = 1
        ")->execute([$duel['team1_id']])->fetchAll();
        
        $team2_members = $pdo->prepare("
            SELECT u.id, u.username, u.daric_balance
            FROM team_members tm
            JOIN users u ON tm.user_id = u.id
            WHERE tm.team_id = ? AND tm.is_active = 1
        ")->execute([$duel['team2_id']])->fetchAll();
        
        // محاسبه سهم هر عضو
        $share = ceil($duel['cost'] / max(count($team1_members), count($team2_members)));
        
        // کسر هزینه از اعضا
        foreach ($team1_members as $member) {
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - ? WHERE id = ?")
                ->execute([$share, $member['id']]);
                
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, ?, 'spend', 'هزینه کل کل', ?, 'duel')
            ");
            $transaction_stmt->execute([$member['id'], $share, $duel_id]);
        }
        
        foreach ($team2_members as $member) {
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance - ? WHERE id = ?")
                ->execute([$share, $member['id']]);
                
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, ?, 'spend', 'هزینه کل کل', ?, 'duel')
            ");
            $transaction_stmt->execute([$member['id'], $share, $duel_id]);
        }
        
        // به‌روزرسانی وضعیت کل کل
        $pdo->prepare("
            UPDATE duels 
            SET status = 'accepted', start_time = NOW(), end_time = DATE_ADD(NOW(), INTERVAL 24 HOUR)
            WHERE id = ?
        ")->execute([$duel_id]);
        
        // ارسال پیام به اعضا
        $message = "کل کل بین اکیپ‌های {$duel['team1_name']} و {$duel['team2_name']} شروع شد. شما 24 ساعت وقت دارید در این کل کل شرکت کنید.";
        
        $all_members = array_merge($team1_members, $team2_members);
        foreach ($all_members as $member) {
            $message_stmt = $pdo->prepare("
                INSERT INTO messages 
                (sender_id, receiver_type, receiver_id, subject, message) 
                VALUES (?, 'user', ?, ?, ?)
            ");
            $message_stmt->execute([
                $user_id,
                $member['id'],
                'شروع کل کل',
                $message
            ]);
        }
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'درخواست کل کل با موفقیت پذیرفته شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>