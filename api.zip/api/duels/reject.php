<?php
// api/duels/reject.php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $duel_id = $_POST['duel_id'];
    
    try {
        $pdo->beginTransaction();
        
        // دریافت اطلاعات کل کل
        $duel_stmt = $pdo->prepare("
            SELECT d.*, t1.name as team1_name, t2.name as team2_name
            FROM duels d
            JOIN teams t1 ON d.team1_id = t1.id
            JOIN teams t2 ON d.team2_id = t2.id
            WHERE d.id = ? AND (t1.admin_id = ? OR t2.admin_id = ?)
        ");
        $duel_stmt->execute([$duel_id, $user_id, $user_id]);
        $duel = $duel_stmt->fetch();
        
        if (!$duel) {
            throw new Exception('درخواست کل کل یافت نشد یا شما اجازه این عمل را ندارید');
        }
        
        if ($duel['status'] != 'pending') {
            throw new Exception('این درخواست کل کل قبلاً پردازش شده است');
        }
        
        // بررسی اینکه آیا کاربر ادمین اکیپ مقابل است
        $is_team2_admin = ($duel['team2_id'] == $user_id);
        
        if (!$is_team2_admin) {
            throw new Exception('فقط ادمین اکیپ مقابل می‌تواند درخواست را رد کند');
        }
        
        // به‌روزرسانی وضعیت کل کل
        $pdo->prepare("
            UPDATE duels 
            SET status = 'declined'
            WHERE id = ?
        ")->execute([$duel_id]);
        
        // ارسال پیام به ادمین اکیپ ارسال کننده
        $message_stmt = $pdo->prepare("
            INSERT INTO messages 
            (sender_id, receiver_type, receiver_id, subject, message) 
            VALUES (?, 'user', ?, ?, ?)
        ");
        $message_stmt->execute([
            $user_id,
            $duel['initiator_id'],
            'رد درخواست کل کل',
            'درخواست کل کل شما توسط اکیپ ' . $duel['team2_name'] . ' رد شد.'
        ]);
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'درخواست کل کل با موفقیت رد شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>