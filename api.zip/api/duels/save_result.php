<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => '', 'team_avg' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $duel_id = $_POST['duel_id'];
    $team_id = $_POST['team_id'];
    $score = $_POST['score'];
    $answered_questions = $_POST['answered_questions'];
    
    try {
        $pdo->beginTransaction();
        
        // بررسی آیا کل کل هنوز فعال است
        $duel_stmt = $pdo->prepare("
            SELECT id, end_time 
            FROM duels 
            WHERE id = ? AND status = 'accepted' AND end_time > NOW()
        ");
        $duel_stmt->execute([$duel_id]);
        $duel = $duel_stmt->fetch();
        
        if (!$duel) {
            throw new Exception('زمان کل کل به پایان رسیده است');
        }
        
        // بررسی آیا کاربر عضو اکیپ است
        $member_stmt = $pdo->prepare("
            SELECT id 
            FROM team_members 
            WHERE team_id = ? AND user_id = ? AND is_active = 1
        ");
        $member_stmt->execute([$team_id, $user_id]);
        
        if ($member_stmt->rowCount() === 0) {
            throw new Exception('شما عضو این اکیپ نیستید');
        }
        
        // بررسی آیا کاربر قبلاً شرکت کرده است
        $played_stmt = $pdo->prepare("
            SELECT id 
            FROM duel_results 
            WHERE duel_id = ? AND user_id = ?
        ");
        $played_stmt->execute([$duel_id, $user_id]);
        
        if ($played_stmt->rowCount() > 0) {
            throw new Exception('شما قبلاً در این کل کل شرکت کرده‌اید');
        }
        
        // ذخیره نتایج کاربر
        $result_stmt = $pdo->prepare("
            INSERT INTO duel_results 
            (duel_id, user_id, team_id, score, answered_questions) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $result_stmt->execute([$duel_id, $user_id, $team_id, $score, $answered_questions]);
        
        // محاسبه میانگین امتیاز تیم
        $avg_stmt = $pdo->prepare("
            SELECT AVG(score) as team_avg
            FROM duel_results
            WHERE duel_id = ? AND team_id = ?
        ");
        $avg_stmt->execute([$duel_id, $team_id]);
        $team_avg = $avg_stmt->fetchColumn();
        $response['team_avg'] = round($team_avg, 1);
        
        // بررسی آیا تمام اعضا شرکت کرده‌اند
        $team_members_count = $pdo->prepare("
            SELECT COUNT(*) 
            FROM team_members 
            WHERE team_id = ? AND is_active = 1
        ")->execute([$team_id])->fetchColumn();
        
        $participated_count = $pdo->prepare("
            SELECT COUNT(DISTINCT user_id) 
            FROM duel_results 
            WHERE duel_id = ? AND team_id = ?
        ")->execute([$duel_id, $team_id])->fetchColumn();
        
        // اگر تمام اعضا شرکت کرده‌اند، نتیجه کل کل را محاسبه کن
        if ($team_members_count == $participated_count) {
            // محاسبه میانگین امتیاز تیم مقابل
            $opponent_team_id = ($team_id == $duel['team1_id']) ? $duel['team2_id'] : $duel['team1_id'];
            
            $opponent_avg = $pdo->prepare("
                SELECT AVG(score) 
                FROM duel_results
                WHERE duel_id = ? AND team_id = ?
            ")->execute([$duel_id, $opponent_team_id])->fetchColumn();
            
            // تعیین برنده
            $winner_team_id = null;
            if ($team_avg > $opponent_avg) {
                $winner_team_id = $team_id;
            } elseif ($opponent_avg > $team_avg) {
                $winner_team_id = $opponent_team_id;
            }
            
            // به‌روزرسانی نتیجه کل کل
            $pdo->prepare("
                UPDATE duels 
                SET status = 'completed',
                    team1_score = ?,
                    team2_score = ?,
                    winner_team_id = ?
                WHERE id = ?
            ")->execute([
                $team_id == $duel['team1_id'] ? $team_avg : $opponent_avg,
                $team_id == $duel['team2_id'] ? $team_avg : $opponent_avg,
                $winner_team_id,
                $duel_id
            ]);
            
            // اگر برنده مشخص شد، جایزه را توزیع کن
            if ($winner_team_id) {
                $winner_members = $pdo->prepare("
                    SELECT user_id 
                    FROM team_members 
                    WHERE team_id = ? AND is_active = 1
                ")->execute([$winner_team_id])->fetchAll();
                
                $reward_per_member = floor($duel['cost'] / count($winner_members));
                
                foreach ($winner_members as $member) {
                    $pdo->prepare("UPDATE users SET daric_balance = daric_balance + ? WHERE id = ?")
                        ->execute([$reward_per_member, $member['user_id']]);
                        
                    // ثبت تراکنش
                    $transaction_stmt = $pdo->prepare("
                        INSERT INTO daric_transactions 
                        (user_id, amount, type, description, related_id, related_type) 
                        VALUES (?, ?, 'earn', 'جایزه برد کل کل', ?, 'duel')
                    ");
                    $transaction_stmt->execute([$member['user_id'], $reward_per_member, $duel_id]);
                }
                
                // آپدیت آمار اکیپ برنده
                $pdo->prepare("
                    UPDATE teams 
                    SET total_wins = total_wins + 1 
                    WHERE id = ?
                ")->execute([$winner_team_id]);
                
                // آپدیت آمار اکیپ بازنده
                $loser_team_id = ($winner_team_id == $duel['team1_id']) ? $duel['team2_id'] : $duel['team1_id'];
                $pdo->prepare("
                    UPDATE teams 
                    SET total_losses = total_losses + 1 
                    WHERE id = ?
                ")->execute([$loser_team_id]);
            }
        }
        
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = 'نتایج با موفقیت ذخیره شد';
    } catch (Exception $e) {
        $pdo->rollBack();
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>