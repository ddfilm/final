<?php
require_once '../../includes/db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $category_id = $_POST['category_id'];
    $score = $_POST['score'];
    $total_questions = $_POST['total_questions'];
    $correct_answers = $_POST['correct_answers'];
    $wrong_answers = $total_questions - $correct_answers;
    
    try {
        $pdo->beginTransaction();
        
        // ذخیره نتایج آزمون
        $stmt = $pdo->prepare("
            INSERT INTO practice_games 
            (user_id, category_id, score, total_questions, correct_answers, wrong_answers) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $category_id, $score, $total_questions, $correct_answers, $wrong_answers]);
        
        // محاسبه داریک جایزه (1 داریک به ازای هر امتیاز)
        $daric_reward = floor($score / 10);
        
        if ($daric_reward > 0) {
            // واریز داریک به حساب کاربر
            $pdo->prepare("UPDATE users SET daric_balance = daric_balance + ? WHERE id = ?")
                ->execute([$daric_reward, $user_id]);
            
            // ثبت تراکنش
            $transaction_stmt = $pdo->prepare("
                INSERT INTO daric_transactions 
                (user_id, amount, type, description, related_id, related_type) 
                VALUES (?, ?, 'earn', 'جایزه آزمون تمرینی', ?, 'practice')
            ");
            $transaction_stmt->execute([$user_id, $daric_reward, $category_id]);
        }
        
        $pdo->commit();
        
        $response['success'] = true;
        $response['message'] = 'نتایج با موفقیت ذخیره شد.';
    } catch (PDOException $e) {
        $pdo->rollBack();
        $response['message'] = 'خطا در ذخیره نتایج: ' . $e->getMessage();
    }
} else {
    $response['message'] = 'درخواست نامعتبر';
}

echo json_encode($response);
?>