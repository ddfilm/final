<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// بررسی آیا کاربر ادمین است
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header("Location: /pages/login.php");
    exit();
}

// دریافت 10 کاربر برتر ماه
$top_users = $pdo->query("
    SELECT u.username, SUM(dt.amount) as total_daric
    FROM daric_transactions dt
    JOIN users u ON dt.user_id = u.id
    WHERE dt.type = 'earn' AND dt.created_at >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
    GROUP BY dt.user_id
    ORDER BY total_daric DESC
    LIMIT 10
")->fetchAll();

// دریافت 10 اکیپ برتر در چالش جاری
$top_teams = $pdo->query("
    SELECT t.name, cp.final_score
    FROM challenge_participants cp
    JOIN teams t ON cp.team_id = t.id
    JOIN challenges c ON cp.challenge_id = c.id
    WHERE c.status = 'ongoing'
    ORDER BY cp.final_score DESC
    LIMIT 10
")->fetchAll();

// دریافت آمار کلی
$stats = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM teams) as total_teams,
        (SELECT COUNT(*) FROM questions WHERE is_approved = 1) as approved_questions,
        (SELECT COUNT(*) FROM questions WHERE is_approved = 0) as pending_questions,
        (SELECT COUNT(*) FROM duels WHERE status = 'completed') as completed_duels,
        (SELECT COUNT(*) FROM challenges WHERE status = 'completed') as completed_challenges
")->fetch();

$page_title = "پنل مدیریت";
$active_page = "admin";
require_once '../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <!-- سایدبار مدیریت -->
        <div class="col-md-3 col-lg-2 bg-dark">
            <div class="sidebar-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="/pages/admin.php">
                            <i class="fas fa-tachometer-alt me-2"></i>داشبورد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_users.php">
                            <i class="fas fa-users me-2"></i>مدیریت کاربران
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_teams.php">
                            <i class="fas fa-users-cog me-2"></i>مدیریت اکیپ‌ها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_questions.php">
                            <i class="fas fa-question-circle me-2"></i>مدیریت سوالات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_categories.php">
                            <i class="fas fa-tags me-2"></i>مدیریت دسته‌بندی‌ها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_ads.php">
                            <i class="fas fa-ad me-2"></i>مدیریت تبلیغات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_messages.php">
                            <i class="fas fa-envelope me-2"></i>مدیریت پیام‌ها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/pages/admin_challenges.php">
                            <i class="fas fa-trophy me-2"></i>مدیریت چالش‌ها
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- محتوای اصلی -->
        <div class="col-md-9 col-lg-10">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">داشبورد مدیریت</h1>
            </div>
            
            <!-- کارت‌های آمار کلی -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card bg-purple text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">تعداد کاربران</h6>
                                    <h3 class="mb-0"><?= $stats['total_users'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card bg-orange text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">تعداد اکیپ‌ها</h6>
                                    <h3 class="mb-0"><?= $stats['total_teams'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users-cog fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card bg-dark text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">سوالات تایید شده</h6>
                                    <h3 class="mb-0"><?= $stats['approved_questions'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card bg-secondary text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">سوالات در انتظار</h6>
                                    <h3 class="mb-0"><?= $stats['pending_questions'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-hourglass-half fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">کل کل‌های انجام شده</h6>
                                    <h3 class="mb-0"><?= $stats['completed_duels'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-fist-raised fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card bg-info text-white">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title">چالش‌های انجام شده</h6>
                                    <h3 class="mb-0"><?= $stats['completed_challenges'] ?></h3>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-trophy fa-2x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- 10 کاربر برتر ماه -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <div class="card-header bg-purple text-white">
                            <h5 class="mb-0">10 کاربر برتر این ماه</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-dark table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>رتبه</th>
                                            <th>نام کاربری</th>
                                            <th>داریک</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($top_users as $index => $user): ?>
                                            <tr>
                                                <td><?= $index + 1 ?></td>
                                                <td><?= $user['username'] ?></td>
                                                <td><?= number_format($user['total_daric']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        
                                        <?php if (empty($top_users)): ?>
                                            <tr>
                                                <td colspan="3" class="text-center py-3">داده‌ای وجود ندارد</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 10 اکیپ برتر چالش جاری -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <div class="card-header bg-orange text-white">
                            <h5 class="mb-0">10 اکیپ برتر چالش جاری</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-dark table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>رتبه</th>
                                            <th>نام اکیپ</th>
                                            <th>میانگین</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($top_teams as $index => $team): ?>
                                            <tr>
                                                <td><?= $index + 1 ?></td>
                                                <td><?= $team['name'] ?></td>
                                                <td><?= round($team['final_score'], 1) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        
                                        <?php if (empty($top_teams)): ?>
                                            <tr>
                                                <td colspan="3" class="text-center py-3">چالش فعالی وجود ندارد</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- بخش ارسال پیام -->
            <div class="row">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-dark text-white">
                            <h5 class="mb-0">ارسال پیام</h5>
                        </div>
                        <div class="card-body">
                            <form id="adminMessageForm">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">گیرنده</label>
                                        <select class="form-select" name="receiver_type" id="receiverType">
                                            <option value="all_users">همه کاربران</option>
                                            <option value="user">کاربر خاص</option>
                                            <option value="team">اکیپ خاص</option>
                                        </select>
                                    </div>
                                    <div class="col-md-8 mb-3" id="receiverSelectContainer" style="display: none;">
                                        <label class="form-label">انتخاب گیرنده</label>
                                        <select class="form-select" name="receiver_id" id="receiverSelect"></select>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">موضوع</label>
                                    <input type="text" class="form-control" name="subject" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">متن پیام</label>
                                    <textarea class="form-control" name="message" rows="4" required></textarea>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-purple">ارسال پیام</button>
                                </div>
                            </form>
                            <div id="messageResult" class="mt-3"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // تغییر نوع گیرنده پیام
    $('#receiverType').on('change', function() {
        var receiverType = $(this).val();
        $('#receiverSelectContainer').hide();
        $('#receiverSelect').html('');
        
        if (receiverType === 'user') {
            $.ajax({
                url: '/api/admin/get_users.php',
                method: 'GET',
                success: function(response) {
                    if (response.length > 0) {
                        var options = '<option value="" selected disabled>انتخاب کاربر</option>';
                        $.each(response, function(index, user) {
                            options += '<option value="' + user.id + '">' + user.username + '</option>';
                        });
                        $('#receiverSelect').html(options);
                        $('#receiverSelectContainer').show();
                    }
                }
            });
        } else if (receiverType === 'team') {
            $.ajax({
                url: '/api/admin/get_teams.php',
                method: 'GET',
                success: function(response) {
                    if (response.length > 0) {
                        var options = '<option value="" selected disabled>انتخاب اکیپ</option>';
                        $.each(response, function(index, team) {
                            options += '<option value="' + team.id + '">' + team.name + '</option>';
                        });
                        $('#receiverSelect').html(options);
                        $('#receiverSelectContainer').show();
                    }
                }
            });
        }
    });
    
    // ارسال فرم پیام
    $('#adminMessageForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/admin/send_message.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#messageResult').html('<div class="alert alert-success">پیام با موفقیت ارسال شد</div>');
                    $('#adminMessageForm')[0].reset();
                    $('#receiverSelectContainer').hide();
                } else {
                    $('#messageResult').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
});
</script>

<?php
require_once '../includes/footer.php';
?>