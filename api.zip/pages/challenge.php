<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// بررسی آیا کاربر عضو اکیپ است
$team_stmt = $pdo->prepare("
    SELECT t.id, t.name, tm.is_active
    FROM team_members tm
    JOIN teams t ON tm.team_id = t.id
    WHERE tm.user_id = ? AND tm.is_active = 1
");
$team_stmt->execute([$user_id]);
$team = $team_stmt->fetch();

if (!$team) {
    header("Location: /pages/dashboard.php?error=no_team");
    exit();
}

// دریافت چالش فعال
$challenge_stmt = $pdo->prepare("
    SELECT c.*, 
           COUNT(cp.team_id) as participants_count
    FROM challenges c
    LEFT JOIN challenge_participants cp ON c.id = cp.challenge_id
    WHERE c.status = 'ongoing'
    GROUP BY c.id
    ORDER BY c.start_date DESC
    LIMIT 1
");
$challenge_stmt->execute();
$challenge = $challenge_stmt->fetch();

if (!$challenge) {
    header("Location: /pages/dashboard.php?error=no_active_challenge");
    exit();
}

// بررسی آیا اکیپ کاربر در چالش ثبت نام کرده است
$participation_stmt = $pdo->prepare("
    SELECT cp.* 
    FROM challenge_participants cp
    WHERE cp.challenge_id = ? AND cp.team_id = ?
");
$participation_stmt->execute([$challenge['id'], $team['id']]);
$participation = $participation_stmt->fetch();

// اگر اکیپ ثبت نام نکرده باشد، به صفحه ثبت نام هدایت شود
if (!$participation) {
    header("Location: /pages/challenge_register.php?id=" . $challenge['id']);
    exit();
}

// دریافت نتایج روزانه اکیپ
$daily_results = $pdo->prepare("
    SELECT dcr.day_number, dcr.score, dcr.played_at
    FROM daily_challenge_results dcr
    WHERE dcr.challenge_id = ? AND dcr.team_id = ?
    ORDER BY dcr.day_number
")->execute([$challenge['id'], $team['id']])->fetchAll();

// محاسبه روز جاری در چالش
$start_date = new DateTime($challenge['start_date']);
$today = new DateTime();
$day_number = $today->diff($start_date)->days + 1;

// اگر چالش هنوز شروع نشده باشد
if ($day_number < 1) {
    $day_number = 1;
}

// اگر چالش تمام شده باشد
if ($day_number > 7) {
    $day_number = 7;
}

// بررسی آیا کاربر امروز در چالش شرکت کرده است
$today_played = false;
foreach ($daily_results as $result) {
    if ($result['day_number'] == $day_number) {
        $today_played = true;
        break;
    }
}

// دریافت سوالات اگر کاربر هنوز امروز بازی نکرده باشد
$questions = [];
if (!$today_played && $day_number <= 7) {
    $questions_stmt = $pdo->prepare("
        SELECT id, question, option1, option2, option3, option4, correct_option 
        FROM questions 
        WHERE is_approved = 1
        ORDER BY RAND()
        LIMIT 20
    ");
    $questions_stmt->execute();
    $questions = $questions_stmt->fetchAll();
}

// دریافت رتبه‌بندی اکیپ‌ها
$ranking_stmt = $pdo->prepare("
    SELECT 
        t.id, t.name, t.logo,
        AVG(dcr.score) as avg_score,
        SUM(dcr.score) as total_score
    FROM challenge_participants cp
    JOIN teams t ON cp.team_id = t.id
    LEFT JOIN daily_challenge_results dcr ON cp.challenge_id = dcr.challenge_id AND cp.team_id = dcr.team_id
    WHERE cp.challenge_id = ?
    GROUP BY t.id
    ORDER BY avg_score DESC
    LIMIT 10
");
$ranking_stmt->execute([$challenge['id']]);
$rankings = $ranking_stmt->fetchAll();

// پیدا کردن رتبه اکیپ کاربر
$team_rank = null;
foreach ($rankings as $index => $rank) {
    if ($rank['id'] == $team['id']) {
        $team_rank = $index + 1;
        break;
    }
}

// اگر اکیپ کاربر در 10 تیم برتر نیست، رتبه را محاسبه کن
if ($team_rank === null) {
    $all_teams = $pdo->prepare("
        SELECT 
            t.id,
            AVG(dcr.score) as avg_score
        FROM challenge_participants cp
        JOIN teams t ON cp.team_id = t.id
        LEFT JOIN daily_challenge_results dcr ON cp.challenge_id = dcr.challenge_id AND cp.team_id = dcr.team_id
        WHERE cp.challenge_id = ?
        GROUP BY t.id
        ORDER BY avg_score DESC
    ")->execute([$challenge['id']])->fetchAll();
    
    foreach ($all_teams as $index => $team_data) {
        if ($team_data['id'] == $team['id']) {
            $team_rank = $index + 1;
            break;
        }
    }
}

$page_title = "چالش 7 روزه - " . $team['name'];
$active_page = "challenge";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <!-- اطلاعات چالش -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">اطلاعات چالش</h5>
                </div>
                <div class="card-body">
                    <h4 class="text-orange"><?= $challenge['name'] ?></h4>
                    <p class="mb-3"><?= $challenge['description'] ?></p>
                    
                    <hr>
                    
                    <div class="challenge-info">
                        <p><strong>روز جاری:</strong> <?= $day_number ?> از 7</p>
                        <p><strong>تعداد شرکت‌کنندگان:</strong> <?= $challenge['participants_count'] ?></p>
                        <p><strong>هزینه ثبت‌نام:</strong> <?= number_format($participation['cost']) ?> داریک</p>
                        <p><strong>رتبه اکیپ شما:</strong> 
                            <?= $team_rank ? $team_rank . ' از ' . $challenge['participants_count'] : 'تعیین نشده' ?>
                        </p>
                        <p><strong>میانگین امتیاز:</strong> 
                            <?= $participation['final_score'] ? round($participation['final_score'], 1) : 'هنوز محاسبه نشده' ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- رتبه‌بندی اکیپ‌ها -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-orange text-white">
                    <h5 class="mb-0">10 اکیپ برتر</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>رتبه</th>
                                    <th>اکیپ</th>
                                    <th>میانگین</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rankings as $index => $rank): ?>
                                    <tr class="<?= $rank['id'] == $team['id'] ? 'table-active' : '' ?>">
                                        <td><?= $index + 1 ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?= $rank['logo'] ? '/assets/images/teams/' . $rank['logo'] : '/assets/images/default-team.png' ?>" 
                                                     class="rounded-circle me-2" width="30" alt="<?= $rank['name'] ?>">
                                                <?= $rank['name'] ?>
                                            </div>
                                        </td>
                                        <td><?= round($rank['avg_score'], 1) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($rankings)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-3">هنوز نتیجه‌ای ثبت نشده است</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <!-- پیشرفت روزانه -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">پیشرفت روزانه</h5>
                </div>
                <div class="card-body">
                    <div class="progress-days">
                        <?php for ($i = 1; $i <= 7; $i++): ?>
                            <?php 
                            $day_score = 0;
                            $day_class = '';
                            
                            foreach ($daily_results as $result) {
                                if ($result['day_number'] == $i) {
                                    $day_score = $result['score'];
                                    $day_class = $day_score >= 60 ? 'bg-success' : ($day_score >= 30 ? 'bg-warning' : 'bg-danger');
                                    break;
                                }
                            }
                            
                            if ($i < $day_number && $day_score == 0) {
                                $day_class = 'bg-danger';
                            }
                            ?>
                            
                            <div class="day <?= $i == $day_number ? 'current' : '' ?>">
                                <div class="day-number">روز <?= $i ?></div>
                                <div class="progress">
                                    <div class="progress-bar <?= $day_class ?>" 
                                         role="progressbar" 
                                         style="width: <?= min($day_score, 100) ?>%" 
                                         aria-valuenow="<?= $day_score ?>" 
                                         aria-valuemin="0" 
                                         aria-valuemax="100">
                                    </div>
                                </div>
                                <div class="day-score">
                                    <?= $day_score > 0 ? $day_score : ($i < $day_number ? '0' : '-') ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            
            <?php if ($day_number > 7): ?>
                <!-- اگر چالش تمام شده باشد -->
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">چالش به پایان رسید</h5>
                    </div>
                    <div class="card-body text-center py-5">
                        <h3 class="text-orange mb-4">رتبه نهایی اکیپ شما: <?= $team_rank ?></h3>
                        <p class="lead">میانگین امتیاز: <?= round($participation['final_score'], 1) ?></p>
                        
                        <?php if ($team_rank <= 3): ?>
                            <div class="alert alert-success mt-4">
                                <h4 class="alert-heading">تبریک!</h4>
                                <p class="mb-0">اکیپ شما در بین 3 تیم برتر قرار گرفت و جایزه دریافت کرد.</p>
                            </div>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-content-center gap-3 mt-4">
                            <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-purple">
                                مشاهده اکیپ
                            </a>
                            <a href="/pages/team_admin.php" class="btn btn-orange">
                                مدیریت اکیپ
                            </a>
                        </div>
                    </div>
                </div>
            <?php elseif ($today_played): ?>
                <!-- اگر کاربر امروز شرکت کرده باشد -->
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">امروز شرکت کرده‌اید</h5>
                    </div>
                    <div class="card-body text-center py-5">
                        <?php
                        $today_result = null;
                        foreach ($daily_results as $result) {
                            if ($result['day_number'] == $day_number) {
                                $today_result = $result;
                                break;
                            }
                        }
                        ?>
                        <h3 class="text-orange mb-4">امتیاز امروز شما: <?= $today_result['score'] ?></h3>
                        <p class="lead">فردا می‌توانید دوباره شرکت کنید.</p>
                        
                        <div class="d-flex justify-content-center gap-3 mt-4">
                            <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-purple">
                                مشاهده اکیپ
                            </a>
                            <a href="/pages/challenge_results.php?id=<?= $challenge['id'] ?>" class="btn btn-orange">
                                مشاهده نتایج
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <!-- اگر کاربر هنوز امروز شرکت نکرده باشد -->
                <div class="card shadow-sm">
                    <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">چالش روز <?= $day_number ?></h5>
                        <div>
                            <span id="timer" class="badge bg-orange">20:00</span>
                            <span id="questionCounter" class="badge bg-dark">1/20</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="quizContainer">
                            <div class="text-center py-4">
                                <h4 class="text-orange mb-3">آماده شروع چالش روز <?= $day_number ?> هستید؟</h4>
                                <p class="mb-4">این چالش شامل 20 سوال از تمامی دسته‌بندی‌ها می‌باشد.</p>
                                <p class="mb-4">برای هر سوال 10 ثانیه زمان دارید. هرچه سریع‌تر پاسخ دهید، امتیاز بیشتری دریافت می‌کنید.</p>
                                <button id="startQuiz" class="btn btn-lg btn-orange">شروع چالش</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if (!$today_played && $day_number <= 7): ?>
<script>
$(document).ready(function() {
    const questions = <?= json_encode($questions) ?>;
    let currentQuestion = 0;
    let score = 0;
    let quizStarted = false;
    let timer;
    let questionTimer;
    let timeLeft = 1200; // 20 دقیقه به ثانیه
    let answeredQuestions = 0;
    
    // تابع نمایش سوال
    function showQuestion(index) {
        if (index >= questions.length) {
            endChallenge();
            return;
        }
        
        const question = questions[index];
        $('#questionCounter').text((index + 1) + '/20');
        
        // ایجاد HTML سوال
        let html = `
            <div class="question" data-id="${question.id}">
                <h4 class="mb-4">${question.question}</h4>
                <div class="options">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option1" value="1">
                        <label class="form-check-label" for="option1">${question.option1}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option2" value="2">
                        <label class="form-check-label" for="option2">${question.option2}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option3" value="3">
                        <label class="form-check-label" for="option3">${question.option3}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option4" value="4">
                        <label class="form-check-label" for="option4">${question.option4}</label>
                    </div>
                </div>
                <div class="d-flex justify-content-between mt-4">
                    <button id="eliminateBtn" class="btn btn-sm btn-outline-orange" data-cost="50">
                        حذف 2 گزینه (50 داریک)
                    </button>
                    <button id="nextBtn" class="btn btn-purple" disabled>ادامه</button>
                </div>
            </div>
        `;
        
        $('#quizContainer').html(html);
        
        // ریست تایمر سوال
        clearInterval(questionTimer);
        let questionTime = 10;
        updateQuestionTimer(questionTime);
        
        questionTimer = setInterval(function() {
            questionTime--;
            updateQuestionTimer(questionTime);
            
            if (questionTime <= 0) {
                clearInterval(questionTimer);
                handleTimeout();
            }
        }, 1000);
        
        // فعال کردن دکمه ادامه پس از انتخاب پاسخ
        $('input[name="answer"]').change(function() {
            $('#nextBtn').prop('disabled', false);
        });
        
        // حذف دو گزینه
        $('#eliminateBtn').click(function() {
            if (confirm('آیا مایلید 50 داریک هزینه کنید تا 2 گزینه تصادفی حذف شوند؟')) {
                const correctOption = question.correct_option;
                let optionsToEliminate = [1, 2, 3, 4].filter(opt => opt != correctOption);
                
                // انتخاب تصادفی 2 گزینه غلط
                optionsToEliminate = shuffleArray(optionsToEliminate).slice(0, 2);
                
                // غیرفعال کردن گزینه‌های انتخاب شده
                optionsToEliminate.forEach(opt => {
                    $(`#option${opt}`).prop('disabled', true).parent().addClass('text-muted');
                });
                
                $(this).prop('disabled', true);
                
                // کسر هزینه از حساب کاربر
                $.ajax({
                    url: '/api/user/deduct_daric.php',
                    method: 'POST',
                    data: { amount: 50, description: 'حذف گزینه در چالش' },
                    success: function(response) {
                        if (!response.success) {
                            alert(response.message);
                        }
                    }
                });
            }
        });
        
        // رفتن به سوال بعدی
        $('#nextBtn').click(function() {
            clearInterval(questionTimer);
            processAnswer(question, questionTime);
        });
    }
    
    // تابع پردازش پاسخ
    function processAnswer(question, timeLeft) {
        const selectedOption = $('input[name="answer"]:checked').val();
        let questionScore = 0;
        let timeFactor = 0;
        
        // محاسبه امتیاز بر اساس زمان پاسخگویی
        if (selectedOption == question.correct_option) {
            answeredQuestions++;
            
            if (timeLeft >= 8) timeFactor = 5; // 2 ثانیه اول
            else if (timeLeft >= 6) timeFactor = 4; // 4 ثانیه اول
            else if (timeLeft >= 4) timeFactor = 3; // 6 ثانیه اول
            else if (timeLeft >= 2) timeFactor = 2; // 8 ثانیه اول
            else timeFactor = 1; // 10 ثانیه اول
            
            questionScore = timeFactor;
            score += questionScore;
        }
        
        // نمایش پاسخ صحیح
        $('.options .form-check-input').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        if (selectedOption && selectedOption != question.correct_option) {
            $(`#option${selectedOption}`).parent().addClass('text-danger');
        }
        
        // نمایش نتیجه سوال
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
        
        const resultHtml = `
            <div class="alert ${selectedOption == question.correct_option ? 'alert-success' : 'alert-danger'} mt-3">
                ${selectedOption == question.correct_option ? 
                    `پاسخ صحیح! (+${questionScore} امتیاز)` : 
                    'پاسخ اشتباه! (0 امتیاز)'}
                <div class="mt-2">
                    <button class="btn btn-sm btn-purple" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `;
        
        $('#quizContainer .question').append(resultHtml);
    }
    
    // تابع پایان چالش
    function endChallenge() {
        clearInterval(timer);
        clearInterval(questionTimer);
        
        // ارسال نتایج به سرور
        $.ajax({
            url: '/api/challenges/save_result.php',
            method: 'POST',
            data: {
                challenge_id: <?= $challenge['id'] ?>,
                team_id: <?= $team['id'] ?>,
                day_number: <?= $day_number ?>,
                score: score,
                answered_questions: answeredQuestions
            },
            success: function(response) {
                const html = `
                    <div class="text-center py-5">
                        <h3 class="text-orange mb-4">چالش روز ${<?= $day_number ?>} به پایان رسید!</h3>
                        <div class="final-score mb-4">
                            <h1 class="display-1 ${score >= 70 ? 'text-success' : score >= 40 ? 'text-warning' : 'text-danger'}">
                                ${score}
                            </h1>
                            <p class="lead">امتیاز امروز شما</p>
                        </div>
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-6">
                                <div class="card bg-dark">
                                    <div class="card-body">
                                        <p>پاسخ‌های صحیح: <strong>${Math.round(score / 5)} از 20</strong></p>
                                        <p>میانگین امتیاز اکیپ شما: <strong>${response.team_avg}</strong></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="/pages/team.php?id=${<?= $team['id'] ?>}" class="btn btn-purple">
                                مشاهده اکیپ
                            </a>
                            <a href="/pages/challenge.php" class="btn btn-orange">
                                مشاهده چالش
                            </a>
                        </div>
                    </div>
                `;
                
                $('#quizContainer').html(html);
            }
        });
    }
    
    // تابع نمایش تایمر
    function updateTimer() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        $('#timer').text(`${minutes}:${seconds < 10 ? '0' + seconds : seconds}`);
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            endChallenge();
        } else {
            timeLeft--;
        }
    }
    
    // تابع نمایش تایمر سوال
    function updateQuestionTimer(seconds) {
        const $timer = $('#timer');
        $timer.removeClass('bg-danger bg-warning');
        
        if (seconds <= 3) {
            $timer.addClass('bg-danger');
        } else if (seconds <= 6) {
            $timer.addClass('bg-warning');
        }
        
        $timer.text(`0:${seconds < 10 ? '0' + seconds : seconds}`);
    }
    
    // تابع زمان‌دهی پاسخ
    function handleTimeout() {
        const question = questions[currentQuestion];
        $('input[name="answer"]').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        $('#quizContainer').append(`
            <div class="alert alert-warning mt-3">
                زمان شما برای پاسخگویی به پایان رسید!
                <div class="mt-2">
                    <button class="btn btn-sm btn-purple" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `);
        
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
    }
    
    // تابع رفتن به سوال بعدی (برای استفاده در HTML)
    window.nextQuestion = function() {
        currentQuestion++;
        showQuestion(currentQuestion);
    };
    
    // تابع شروع آزمون
    $('#startQuiz').click(function() {
        quizStarted = true;
        showQuestion(0);
        
        // شروع تایمر کلی
        timer = setInterval(updateTimer, 1000);
    });
    
    // تابع تصادفی سازی آرایه
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});
</script>
<?php endif; ?>

<?php
require_once '../includes/footer.php';
?>