<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// دریافت اطلاعات چالش
$challenge_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$challenge_stmt = $pdo->prepare("
    SELECT c.*, 
           COUNT(cp.team_id) as participants_count
    FROM challenges c
    LEFT JOIN challenge_participants cp ON c.id = cp.challenge_id
    WHERE c.id = ? AND c.status = 'upcoming'
    GROUP BY c.id
");
$challenge_stmt->execute([$challenge_id]);
$challenge = $challenge_stmt->fetch();

if (!$challenge) {
    header("Location: /pages/dashboard.php?error=invalid_challenge");
    exit();
}

// بررسی آیا کاربر عضو اکیپ است
$team_stmt = $pdo->prepare("
    SELECT t.id, t.name, t.admin_id, 
           COUNT(tm.user_id) as member_count
    FROM team_members tm
    JOIN teams t ON tm.team_id = t.id
    WHERE tm.user_id = ? AND tm.is_active = 1
    GROUP BY t.id
");
$team_stmt->execute([$user_id]);
$team = $team_stmt->fetch();

if (!$team) {
    header("Location: /pages/dashboard.php?error=no_team");
    exit();
}

// بررسی آیا اکیپ قبلاً ثبت نام کرده است
$participation_stmt = $pdo->prepare("
    SELECT id 
    FROM challenge_participants 
    WHERE challenge_id = ? AND team_id = ?
");
$participation_stmt->execute([$challenge_id, $team['id']]);

if ($participation_stmt->rowCount() > 0) {
    header("Location: /pages/challenge.php");
    exit();
}

// محاسبه هزینه ثبت نام (100 داریک به ازای هر عضو)
$cost = $team['member_count'] * 100;

$page_title = "ثبت نام در چالش - " . $challenge['name'];
$active_page = "challenge";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">ثبت نام در چالش <?= $challenge['name'] ?></h5>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <h4 class="text-orange"><?= $challenge['name'] ?></h4>
                        <p class="lead"><?= $challenge['description'] ?></p>
                        <p>تاریخ شروع: <?= jdate('Y/m/d', strtotime($challenge['start_date'])) ?></p>
                        <p>تاریخ پایان: <?= jdate('Y/m/d', strtotime($challenge['end_date'])) ?></p>
                        <p class="text-muted"><?= $challenge['participants_count'] ?> اکیپ تاکنون ثبت نام کرده‌اند</p>
                    </div>
                    
                    <hr>
                    
                    <div class="team-info text-center mb-4">
                        <h5 class="text-purple">اکیپ شما</h5>
                        <img src="<?= $team['logo'] ? '/assets/images/teams/' . $team['logo'] : '/assets/images/default-team.png' ?>" 
                             class="rounded-circle mb-2" width="100" alt="<?= $team['name'] ?>">
                        <h4><?= $team['name'] ?></h4>
                        <p>تعداد اعضا: <?= $team['member_count'] ?></p>
                    </div>
                    
                    <div class="alert alert-info">
                        <h5 class="alert-heading">هزینه ثبت نام:</h5>
                        <p class="mb-0"><?= number_format($cost) ?> داریک (100 داریک به ازای هر عضو)</p>
                        <p class="mb-0">این مبلغ به طور مساوی از حساب تمام اعضا کسر خواهد شد.</p>
                    </div>
                    
                    <?php if ($team['admin_id'] == $user_id): ?>
                        <form id="registerForm">
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-orange btn-lg">
                                    تایید و ثبت نام
                                </button>
                                <a href="/pages/challenge.php" class="btn btn-outline-secondary">
                                    انصراف
                                </a>
                            </div>
                        </form>
                        <div id="registerMessage" class="mt-3"></div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <p class="mb-0">فقط ادمین اکیپ می‌تواند در چالش ثبت نام کند.</p>
                        </div>
                        <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-purple">
                            بازگشت به صفحه اکیپ
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($team['admin_id'] == $user_id): ?>
<script>
$(document).ready(function() {
    // ارسال فرم ثبت نام
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '/api/challenges/register.php',
            method: 'POST',
            data: {
                challenge_id: <?= $challenge['id'] ?>,
                team_id: <?= $team['id'] ?>
            },
            success: function(response) {
                if (response.success) {
                    $('#registerMessage').html(`
                        <div class="alert alert-success">
                            <p class="mb-0">ثبت نام با موفقیت انجام شد. اکنون می‌توانید در چالش شرکت کنید.</p>
                        </div>
                    `);
                    
                    setTimeout(() => {
                        window.location.href = '/pages/challenge.php';
                    }, 2000);
                } else {
                    $('#registerMessage').html(`
                        <div class="alert alert-danger">
                            <p class="mb-0">${response.message}</p>
                        </div>
                    `);
                }
            }
        });
    });
});
</script>
<?php endif; ?>

<?php
require_once '../includes/footer.php';
?>