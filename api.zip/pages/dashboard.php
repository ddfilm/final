<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// دریافت اطلاعات کاربر
$user_stmt = $pdo->prepare("SELECT username, telegram_id, daric_balance FROM users WHERE id = ?");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();

// دریافت اطلاعات اکیپ کاربر
$team_stmt = $pdo->prepare("
    SELECT t.id, t.name, t.logo, t.admin_id 
    FROM teams t
    JOIN team_members tm ON t.id = tm.team_id
    WHERE tm.user_id = ? AND tm.is_active = 1
");
$team_stmt->execute([$user_id]);
$team = $team_stmt->fetch();

// آمار بازی‌های تمرینی
$practice_stats = $pdo->prepare("
    SELECT 
        COUNT(*) as total_games,
        AVG(score) as avg_score,
        MAX(score) as max_score,
        MIN(score) as min_score
    FROM practice_games 
    WHERE user_id = ?
")->execute([$user_id]);
$practice_stats = $practice_stats->fetch();

// 10 بازی اخیر
$recent_games = $pdo->prepare("
    SELECT pg.score, pg.played_at, c.name as category_name
    FROM practice_games pg
    JOIN categories c ON pg.category_id = c.id
    WHERE pg.user_id = ?
    ORDER BY pg.played_at DESC
    LIMIT 10
")->execute([$user_id]);
$recent_games = $recent_games->fetchAll();

// پیام‌های خوانده نشده
$unread_messages = $pdo->prepare("
    SELECT COUNT(*) as unread_count
    FROM messages
    WHERE receiver_type = 'user' AND receiver_id = ? AND is_read = 0
")->execute([$user_id]);
$unread_messages = $unread_messages->fetch();

$page_title = "داشبورد کاربر - " . $user['username'];
$active_page = "dashboard";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <!-- بخش سمت راست - اطلاعات کاربر -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <div class="avatar mb-3">
                        <img src="/assets/images/default-avatar.png" class="rounded-circle" width="100" alt="آواتار">
                    </div>
                    <h4 class="text-purple"><?= $user['username'] ?></h4>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-muted">موجودی داریک:</span>
                        <span class="fw-bold text-orange"><?= number_format($user['daric_balance']) ?></span>
                    </div>
                    
                    <hr>
                    
                    <?php if ($team): ?>
                        <div class="team-info mb-3">
                            <h5 class="text-purple">اکیپ شما</h5>
                            <div class="d-flex align-items-center">
                                <img src="<?= $team['logo'] ? '/assets/images/teams/' . $team['logo'] : '/assets/images/default-team.png' ?>" 
                                     class="rounded-circle me-2" width="40" alt="لوگوی اکیپ">
                                <span><?= $team['name'] ?></span>
                                <?php if ($team['admin_id'] == $user_id): ?>
                                    <span class="badge bg-orange ms-2">ادمین</span>
                                <?php endif; ?>
                            </div>
                            <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-sm btn-purple mt-2">مشاهده اکیپ</a>
                            <?php if ($team['admin_id'] == $user_id): ?>
                                <a href="/pages/team_admin.php" class="btn btn-sm btn-orange mt-2">مدیریت اکیپ</a>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <p class="mb-2">شما عضو هیچ اکیپی نیستید.</p>
                            <button class="btn btn-sm btn-purple" data-bs-toggle="modal" data-bs-target="#createTeamModal">
                                ساخت اکیپ جدید
                            </button>
                        </div>
                    <?php endif; ?>
                    
                    <hr>
                    
                    <div class="telegram-section">
                        <h5 class="text-purple">پیوند تلگرام</h5>
                        <?php if ($user['telegram_id']): ?>
                            <p class="text-success">متصل شده است</p>
                            <button class="btn btn-sm btn-outline-danger" id="disconnectTelegram">قطع اتصال</button>
                        <?php else: ?>
                            <p class="text-muted">متصل نشده است</p>
                            <button class="btn btn-sm btn-outline-purple" id="connectTelegram">اتصال حساب تلگرام</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- بخش طراحی سوال -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-purple text-white">
                    طراحی سوال جدید
                </div>
                <div class="card-body">
                    <form id="questionForm">
                        <div class="mb-3">
                            <label class="form-label">دسته بندی</label>
                            <select class="form-select" name="category" required>
                                <option value="" selected disabled>انتخاب کنید</option>
                                <?php
                                $categories = $pdo->query("SELECT id, name FROM categories WHERE is_active = 1")->fetchAll();
                                foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= $cat['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">متن سوال</label>
                            <textarea class="form-control" name="question" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">گزینه ۱ (پاسخ صحیح)</label>
                            <input type="text" class="form-control" name="option1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">گزینه ۲</label>
                            <input type="text" class="form-control" name="option2" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">گزینه ۳</label>
                            <input type="text" class="form-control" name="option3" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">گزینه ۴</label>
                            <input type="text" class="form-control" name="option4" required>
                        </div>
                        <button type="submit" class="btn btn-orange w-100">ارسال برای بررسی</button>
                    </form>
                    <div id="questionMessage" class="mt-3"></div>
                </div>
            </div>
        </div>
        
        <!-- بخش سمت چپ - آمار و اطلاعات -->
        <div class="col-md-8">
            <!-- کارت‌های خلاصه آمار -->
            <div class="row mb-4">
                <div class="col-md-6 mb-3">
                    <div class="card bg-dark text-white shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">تعداد بازی‌ها</h6>
                                    <h3 class="mb-0"><?= $practice_stats['total_games'] ?></h3>
                                </div>
                                <div class="icon bg-purple">
                                    <i class="fas fa-gamepad"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card bg-dark text-white shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">میانگین امتیاز</h6>
                                    <h3 class="mb-0"><?= round($practice_stats['avg_score'], 1) ?></h3>
                                </div>
                                <div class="icon bg-orange">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card bg-dark text-white shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">بالاترین امتیاز</h6>
                                    <h3 class="mb-0"><?= $practice_stats['max_score'] ?></h3>
                                </div>
                                <div class="icon bg-success">
                                    <i class="fas fa-trophy"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card bg-dark text-white shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-muted">پایین‌ترین امتیاز</h6>
                                    <h3 class="mb-0"><?= $practice_stats['min_score'] ?></h3>
                                </div>
                                <div class="icon bg-danger">
                                    <i class="fas fa-chart-bar"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- بازی‌های اخیر -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center">
                    <span>10 بازی اخیر</span>
                    <a href="/pages/practice.php" class="btn btn-sm btn-orange">شروع بازی جدید</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>دسته بندی</th>
                                    <th>امتیاز</th>
                                    <th>تاریخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_games as $game): ?>
                                    <tr>
                                        <td><?= $game['category_name'] ?></td>
                                        <td><?= $game['score'] ?></td>
                                        <td><?= jdate('Y/m/d H:i', strtotime($game['played_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($recent_games)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-4">هنوز بازی‌ای انجام نداده‌اید</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- پیام‌ها -->
            <div class="card shadow-sm">
                <div class="card-header bg-orange text-white d-flex justify-content-between align-items-center">
                    <span>پیام‌ها</span>
                    <div>
                        <button class="btn btn-sm btn-purple me-2" data-bs-toggle="modal" data-bs-target="#newMessageModal">
                            ارسال پیام جدید
                        </button>
                        <span class="badge bg-dark"><?= $unread_messages['unread_count'] ?> خوانده نشده</span>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <a href="/pages/messages.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <span>صندوق دریافت</span>
                            <i class="fas fa-inbox"></i>
                        </a>
                        <a href="/pages/messages.php?outbox=1" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <span>صندوق ارسال</span>
                            <i class="fas fa-paper-plane"></i>
                        </a>
                        <a href="/pages/messages.php?admin=1" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            <span>پیام به ادمین</span>
                            <i class="fas fa-headset"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- مودال ساخت اکیپ جدید -->
<div class="modal fade" id="createTeamModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-purple text-white">
                <h5 class="modal-title">ساخت اکیپ جدید</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="createTeamForm">
                    <div class="mb-3">
                        <label class="form-label">نام اکیپ</label>
                        <input type="text" class="form-control" name="team_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">لوگوی اکیپ (اختیاری)</label>
                        <input type="file" class="form-control" name="team_logo" accept="image/*">
                        <small class="form-text text-muted">تصویر مربع با حداکثر سایز 512x512 پیکسل</small>
                    </div>
                    <div class="alert alert-info">
                        <p class="mb-0">برای ساخت اکیپ، 500 داریک از حساب شما کسر خواهد شد.</p>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-orange">ساخت اکیپ</button>
                    </div>
                </form>
                <div id="teamMessage" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<!-- مودال ارسال پیام جدید -->
<div class="modal fade" id="newMessageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-orange text-white">
                <h5 class="modal-title">ارسال پیام جدید</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="newMessageForm">
                    <div class="mb-3">
                        <label class="form-label">گیرنده</label>
                        <select class="form-select" name="receiver_type" id="receiverType" required>
                            <option value="" selected disabled>انتخاب کنید</option>
                            <option value="admin">ادمین سایت</option>
                            <?php if ($team): ?>
                                <option value="team_member">عضو اکیپ</option>
                            <?php endif; ?>
                            <option value="user">کاربر دیگر</option>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="receiverSelectContainer" style="display: none;">
                        <label class="form-label">انتخاب گیرنده</label>
                        <select class="form-select" name="receiver_id" id="receiverSelect"></select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">موضوع</label>
                        <input type="text" class="form-control" name="subject" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">متن پیام</label>
                        <textarea class="form-control" name="message" rows="4" required></textarea>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-purple">ارسال پیام</button>
                    </div>
                </form>
                <div id="messageResult" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // ارسال فرم طراحی سوال
    $('#questionForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/questions/submit.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#questionMessage').html('<div class="alert alert-success">سوال با موفقیت ثبت شد و پس از تایید، 100 داریک به حساب شما واریز خواهد شد.</div>');
                    $('#questionForm')[0].reset();
                } else {
                    $('#questionMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // ارسال فرم ساخت اکیپ
    $('#createTeamForm').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        
        $.ajax({
            url: '/api/teams/create.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $('#teamMessage').html('<div class="alert alert-success">اکیپ با موفقیت ایجاد شد!</div>');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    $('#teamMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // تغییر نوع گیرنده پیام
    $('#receiverType').on('change', function() {
        var receiverType = $(this).val();
        $('#receiverSelectContainer').hide();
        $('#receiverSelect').html('');
        
        if (receiverType === 'team_member') {
            $.ajax({
                url: '/api/teams/get_members.php',
                method: 'GET',
                success: function(response) {
                    if (response.length > 0) {
                        var options = '';
                        $.each(response, function(index, member) {
                            options += '<option value="' + member.id + '">' + member.username + '</option>';
                        });
                        $('#receiverSelect').html(options);
                        $('#receiverSelectContainer').show();
                    }
                }
            });
        } else if (receiverType === 'user') {
            // در اینجا می‌توانید لیست کاربران را از سرور دریافت کنید
            // برای سادگی، این بخش را می‌توانید بعداً پیاده‌سازی کنید
            $('#receiverSelectContainer').show();
            $('#receiverSelect').html('<option value="" selected disabled>در حال بارگذاری...</option>');
        }
    });
    
    // ارسال فرم پیام جدید
    $('#newMessageForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/messages/send.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#messageResult').html('<div class="alert alert-success">پیام با موفقیت ارسال شد.</div>');
                    $('#newMessageForm')[0].reset();
                    setTimeout(function() {
                        $('#newMessageModal').modal('hide');
                    }, 1500);
                } else {
                    $('#messageResult').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // اتصال/قطع اتصال تلگرام
    $('#connectTelegram').on('click', function() {
        // این بخش نیاز به پیاده‌سازی وب‌هوک تلگرام دارد
        alert('لینک اتصال به ربات تلگرام نمایش داده خواهد شد');
    });
    
    $('#disconnectTelegram').on('click', function() {
        if (confirm('آیا مطمئن هستید که می‌خواهید اتصال تلگرام را قطع کنید؟')) {
            $.ajax({
                url: '/api/user/disconnect_telegram.php',
                method: 'POST',
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                }
            });
        }
    });
});
</script>

<?php
require_once '../includes/footer.php';
?>