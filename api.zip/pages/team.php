<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$team_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// دریافت اطلاعات اکیپ
$team_stmt = $pdo->prepare("
    SELECT t.*, u.username as admin_name
    FROM teams t
    JOIN users u ON t.admin_id = u.id
    WHERE t.id = ?
");
$team_stmt->execute([$team_id]);
$team = $team_stmt->fetch();

if (!$team) {
    header("Location: /pages/dashboard.php?error=invalid_team");
    exit();
}

// دریافت اعضای اکیپ
$members_stmt = $pdo->prepare("
    SELECT u.id, u.username, u.daric_balance,
           (SELECT COUNT(*) FROM practice_games WHERE user_id = u.id) as games_played,
           (SELECT AVG(score) FROM practice_games WHERE user_id = u.id) as avg_score
    FROM team_members tm
    JOIN users u ON tm.user_id = u.id
    WHERE tm.team_id = ? AND tm.is_active = 1
    ORDER BY u.daric_balance DESC
");
$members_stmt->execute([$team_id]);
$members = $members_stmt->fetchAll();

// دریافت آمار کل کل‌ها
$duel_stats = $pdo->prepare("
    SELECT 
        SUM(CASE WHEN winner_team_id = ? THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN winner_team_id IS NOT NULL AND winner_team_id != ? THEN 1 ELSE 0 END) as losses,
        SUM(CASE WHEN winner_team_id IS NULL AND status = 'completed' THEN 1 ELSE 0 END) as draws
    FROM duels
    WHERE (team1_id = ? OR team2_id = ?) AND status = 'completed'
")->execute([$team_id, $team_id, $team_id, $team_id])->fetch();

// دریافت افتخارات اکیپ
$achievements = $pdo->prepare("
    SELECT 
        COUNT(*) as challenge_wins
    FROM challenge_participants
    WHERE team_id = ? AND final_rank <= 3
")->execute([$team_id])->fetchColumn();

// دریافت پیام‌های ادمین کل
$admin_messages = $pdo->prepare("
    SELECT m.* 
    FROM messages m
    WHERE m.receiver_type = 'team' AND m.receiver_id = ?
    ORDER BY m.sent_at DESC
    LIMIT 5
")->execute([$team_id])->fetchAll();

// بررسی آیا کاربر عضو این اکیپ است
$is_member = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $check_member = $pdo->prepare("
        SELECT id 
        FROM team_members 
        WHERE team_id = ? AND user_id = ? AND is_active = 1
    ")->execute([$team_id, $user_id])->fetch();
    
    $is_member = (bool)$check_member;
}

$page_title = "اکیپ " . $team['name'];
$active_page = "team";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <!-- اطلاعات اکیپ -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">اطلاعات اکیپ</h5>
                </div>
                <div class="card-body text-center">
                    <img src="<?= $team['logo'] ? '/assets/images/teams/' . $team['logo'] : '/assets/images/default-team.png' ?>" 
                         class="rounded-circle mb-3" width="150" alt="<?= $team['name'] ?>">
                    <h3 class="text-orange"><?= $team['name'] ?></h3>
                    <p class="text-muted">تعداد اعضا: <?= count($members) ?></p>
                    
                    <hr>
                    
                    <div class="team-info">
                        <p><strong>ادمین:</strong> <?= $team['admin_name'] ?></p>
                        <p><strong>تاریخ ایجاد:</strong> <?= jdate('Y/m/d', strtotime($team['created_at'])) ?></p>
                    </div>
                    
                    <hr>
                    
                    <div class="team-stats">
                        <div class="d-flex justify-content-between">
                            <span>پیروزی‌ها:</span>
                            <span class="fw-bold"><?= $duel_stats['wins'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>شکست‌ها:</span>
                            <span class="fw-bold"><?= $duel_stats['losses'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>مساوی‌ها:</span>
                            <span class="fw-bold"><?= $duel_stats['draws'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>چالش‌های برنده:</span>
                            <span class="fw-bold"><?= $achievements ?></span>
                        </div>
                    </div>
                    
                    <?php if ($is_member): ?>
                        <hr>
                        <a href="/pages/team_admin.php" class="btn btn-orange w-100">
                            مدیریت اکیپ
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- پیام‌های ادمین کل -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">پیام‌های ادمین</h5>
                </div>
                <div class="card-body p-0">
                    <?php if (!empty($admin_messages)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($admin_messages as $message): ?>
                                <div class="list-group-item list-group-item-dark">
                                    <h6 class="mb-1"><?= $message['subject'] ?></h6>
                                    <p class="mb-1 text-muted small"><?= substr($message['message'], 0, 50) ?>...</p>
                                    <small class="text-muted"><?= jdate('Y/m/d H:i', strtotime($message['sent_at'])) ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <a href="/pages/messages.php?team=<?= $team_id ?>" class="btn btn-sm btn-outline-purple w-100 rounded-0">
                            مشاهده همه پیام‌ها
                        </a>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <p class="text-muted">پیامی وجود ندارد</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <!-- اعضای اکیپ -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-orange text-white">
                    <h5 class="mb-0">اعضای اکیپ</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>نام کاربری</th>
                                    <th>موجودی داریک</th>
                                    <th>تعداد بازی‌ها</th>
                                    <th>میانگین امتیاز</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($members as $index => $member): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td>
                                            <a href="/pages/user_profile.php?id=<?= $member['id'] ?>" class="text-white">
                                                <?= $member['username'] ?>
                                                <?php if ($member['id'] == $team['admin_id']): ?>
                                                    <span class="badge bg-purple">ادمین</span>
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                        <td><?= number_format($member['daric_balance']) ?></td>
                                        <td><?= $member['games_played'] ?></td>
                                        <td><?= round($member['avg_score'], 1) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- رتبه‌بندی ماهانه اعضا -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">رتبه‌بندی ماهانه اعضا</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>نام کاربری</th>
                                    <th>داریک این ماه</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $monthly_ranking = $pdo->prepare("
                                    SELECT u.id, u.username, SUM(dt.amount) as total_daric
                                    FROM daric_transactions dt
                                    JOIN users u ON dt.user_id = u.id
                                    JOIN team_members tm ON u.id = tm.user_id
                                    WHERE dt.type = 'earn' 
                                    AND dt.created_at >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
                                    AND tm.team_id = ? AND tm.is_active = 1
                                    GROUP BY dt.user_id
                                    ORDER BY total_daric DESC
                                    LIMIT 5
                                ")->execute([$team_id])->fetchAll();
                                
                                foreach ($monthly_ranking as $index => $member): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><?= $member['username'] ?></td>
                                        <td><?= number_format($member['total_daric']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($monthly_ranking)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-3">داده‌ای وجود ندارد</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- بازیکنان برتر در کل کل‌ها -->
            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">بازیکنان برتر در کل کل‌ها</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>نام کاربری</th>
                                    <th>میانگین امتیاز</th>
                                    <th>تعداد شرکت</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $duel_top_players = $pdo->prepare("
                                    SELECT u.id, u.username, 
                                           AVG(dr.score) as avg_score,
                                           COUNT(dr.id) as participation_count
                                    FROM duel_results dr
                                    JOIN users u ON dr.user_id = u.id
                                    JOIN team_members tm ON u.id = tm.user_id
                                    WHERE tm.team_id = ? AND tm.is_active = 1
                                    GROUP BY dr.user_id
                                    ORDER BY avg_score DESC
                                    LIMIT 5
                                ")->execute([$team_id])->fetchAll();
                                
                                foreach ($duel_top_players as $index => $player): ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><?= $player['username'] ?></td>
                                        <td><?= round($player['avg_score'], 1) ?></td>
                                        <td><?= $player['participation_count'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($duel_top_players)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-3">داده‌ای وجود ندارد</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../includes/footer.php';
?>