<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// بررسی آیا کاربر عضو اکیپ است
$team_stmt = $pdo->prepare("
    SELECT t.id, t.name, tm.is_active
    FROM team_members tm
    JOIN teams t ON tm.team_id = t.id
    WHERE tm.user_id = ? AND tm.is_active = 1
");
$team_stmt->execute([$user_id]);
$team = $team_stmt->fetch();

if (!$team) {
    header("Location: /pages/dashboard.php?error=no_team");
    exit();
}

// دریافت کل کل فعال
$duel_stmt = $pdo->prepare("
    SELECT d.*, 
           t1.name as team1_name, t1.logo as team1_logo,
           t2.name as team2_name, t2.logo as team2_logo
    FROM duels d
    JOIN teams t1 ON d.team1_id = t1.id
    JOIN teams t2 ON d.team2_id = t2.id
    WHERE (d.team1_id = ? OR d.team2_id = ?) 
    AND d.status = 'accepted'
    AND d.end_time > NOW()
    ORDER BY d.start_time DESC
    LIMIT 1
");
$duel_stmt->execute([$team['id'], $team['id']]);
$duel = $duel_stmt->fetch();

if (!$duel) {
    header("Location: /pages/team_admin.php?error=no_active_duel");
    exit();
}

// بررسی آیا کاربر قبلاً در این کل کل شرکت کرده است
$played_stmt = $pdo->prepare("
    SELECT id FROM duel_results 
    WHERE duel_id = ? AND user_id = ?
");
$played_stmt->execute([$duel['id'], $user_id]);
$has_played = $played_stmt->fetch();

// دریافت سوالات اگر کاربر هنوز بازی نکرده باشد
$questions = [];
if (!$has_played) {
    $questions_stmt = $pdo->prepare("
        SELECT id, question, option1, option2, option3, option4, correct_option 
        FROM questions 
        WHERE is_approved = 1
        ORDER BY RAND()
        LIMIT 20
    ");
    $questions_stmt->execute();
    $questions = $questions_stmt->fetchAll();
}

// دریافت آمار تیم‌ها
$team1_stats = $pdo->prepare("
    SELECT COUNT(*) as member_count,
           AVG(dr.score) as avg_score
    FROM duel_results dr
    WHERE dr.duel_id = ? AND dr.team_id = ?
")->execute([$duel['id'], $duel['team1_id']])->fetch();

$team2_stats = $pdo->prepare("
    SELECT COUNT(*) as member_count,
           AVG(dr.score) as avg_score
    FROM duel_results dr
    WHERE dr.duel_id = ? AND dr.team_id = ?
")->execute([$duel['id'], $duel['team2_id']])->fetch();

// محاسبه زمان باقیمانده
$now = new DateTime();
$end_time = new DateTime($duel['end_time']);
$time_left = $now->diff($end_time);

$page_title = "کل کل - " . $team['name'];
$active_page = "duel";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <!-- اطلاعات کل کل -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">اطلاعات کل کل</h5>
                </div>
                <div class="card-body">
                    <div class="teams-info text-center">
                        <div class="d-flex justify-content-around align-items-center mb-4">
                            <div class="team">
                                <img src="<?= $duel['team1_logo'] ? '/assets/images/teams/' . $duel['team1_logo'] : '/assets/images/default-team.png' ?>" 
                                     class="rounded-circle mb-2" width="80" alt="<?= $duel['team1_name'] ?>">
                                <h5><?= $duel['team1_name'] ?></h5>
                                <p class="mb-1">میانگین امتیاز: <?= round($team1_stats['avg_score'], 1) ?></p>
                                <p>تعداد شرکت‌کنندگان: <?= $team1_stats['member_count'] ?></p>
                            </div>
                            <div class="vs-text">
                                <span class="badge bg-orange">VS</span>
                            </div>
                            <div class="team">
                                <img src="<?= $duel['team2_logo'] ? '/assets/images/teams/' . $duel['team2_logo'] : '/assets/images/default-team.png' ?>" 
                                     class="rounded-circle mb-2" width="80" alt="<?= $duel['team2_name'] ?>">
                                <h5><?= $duel['team2_name'] ?></h5>
                                <p class="mb-1">میانگین امتیاز: <?= round($team2_stats['avg_score'], 1) ?></p>
                                <p>تعداد شرکت‌کنندگان: <?= $team2_stats['member_count'] ?></p>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <div class="duel-info">
                            <p><strong>هزینه کل کل:</strong> <?= number_format($duel['cost']) ?> داریک</p>
                            <p><strong>زمان باقیمانده:</strong> 
                                <?= $time_left->h ?> ساعت و <?= $time_left->i ?> دقیقه
                            </p>
                            <p><strong>سهم هر عضو:</strong> 
                                <?= number_format(ceil($duel['cost'] / max($team1_stats['member_count'], $team2_stats['member_count']))) ?> داریک
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- رتبه‌بندی اعضا -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-orange text-white">
                    <h5 class="mb-0">برترین‌های اکیپ شما</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>نام کاربری</th>
                                    <th>امتیاز</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $top_members = $pdo->prepare("
                                    SELECT u.username, dr.score
                                    FROM duel_results dr
                                    JOIN users u ON dr.user_id = u.id
                                    WHERE dr.duel_id = ? AND dr.team_id = ?
                                    ORDER BY dr.score DESC
                                    LIMIT 5
                                ")->execute([$duel['id'], $team['id']])->fetchAll();
                                
                                foreach ($top_members as $member): ?>
                                    <tr>
                                        <td><?= $member['username'] ?></td>
                                        <td><?= $member['score'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($top_members)): ?>
                                    <tr>
                                        <td colspan="2" class="text-center py-3">هنوز کسی شرکت نکرده است</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <?php if ($has_played): ?>
                <!-- اگر کاربر قبلاً شرکت کرده است -->
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">شما قبلاً در این کل کل شرکت کرده‌اید</h5>
                    </div>
                    <div class="card-body text-center py-5">
                        <?php
                        $user_result = $pdo->prepare("
                            SELECT score, answered_questions
                            FROM duel_results
                            WHERE duel_id = ? AND user_id = ?
                        ")->execute([$duel['id'], $user_id])->fetch();
                        ?>
                        <h3 class="text-orange mb-4">امتیاز شما: <?= $user_result['score'] ?></h3>
                        <p class="lead">شما به <?= $user_result['answered_questions'] ?> سوال از 20 سوال پاسخ دادید.</p>
                        
                        <div class="d-flex justify-content-center gap-3 mt-4">
                            <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-purple">
                                مشاهده اکیپ
                            </a>
                            <a href="/pages/team_admin.php" class="btn btn-orange">
                                مدیریت اکیپ
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <!-- اگر کاربر هنوز شرکت نکرده است -->
                <div class="card shadow-sm">
                    <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">کل کل - سوالات</h5>
                        <div>
                            <span id="timer" class="badge bg-orange">20:00</span>
                            <span id="questionCounter" class="badge bg-dark">1/20</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="quizContainer">
                            <div class="text-center py-4">
                                <h4 class="text-orange mb-3">آماده شروع کل کل هستید؟</h4>
                                <p class="mb-4">این کل کل شامل 20 سوال از تمامی دسته‌بندی‌ها می‌باشد.</p>
                                <p class="mb-4">برای هر سوال 10 ثانیه زمان دارید. هرچه سریع‌تر پاسخ دهید، امتیاز بیشتری دریافت می‌کنید.</p>
                                <button id="startQuiz" class="btn btn-lg btn-orange">شروع کل کل</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if (!$has_played): ?>
<script>
$(document).ready(function() {
    const questions = <?= json_encode($questions) ?>;
    let currentQuestion = 0;
    let score = 0;
    let quizStarted = false;
    let timer;
    let questionTimer;
    let timeLeft = 1200; // 20 دقیقه به ثانیه
    let answeredQuestions = 0;
    
    // تابع نمایش سوال
    function showQuestion(index) {
        if (index >= questions.length) {
            endDuel();
            return;
        }
        
        const question = questions[index];
        $('#questionCounter').text((index + 1) + '/20');
        
        // ایجاد HTML سوال
        let html = `
            <div class="question" data-id="${question.id}">
                <h4 class="mb-4">${question.question}</h4>
                <div class="options">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option1" value="1">
                        <label class="form-check-label" for="option1">${question.option1}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option2" value="2">
                        <label class="form-check-label" for="option2">${question.option2}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option3" value="3">
                        <label class="form-check-label" for="option3">${question.option3}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option4" value="4">
                        <label class="form-check-label" for="option4">${question.option4}</label>
                    </div>
                </div>
                <div class="d-flex justify-content-between mt-4">
                    <button id="eliminateBtn" class="btn btn-sm btn-outline-orange" data-cost="50">
                        حذف 2 گزینه (50 داریک)
                    </button>
                    <button id="nextBtn" class="btn btn-purple" disabled>ادامه</button>
                </div>
            </div>
        `;
        
        $('#quizContainer').html(html);
        
        // ریست تایمر سوال
        clearInterval(questionTimer);
        let questionTime = 10;
        updateQuestionTimer(questionTime);
        
        questionTimer = setInterval(function() {
            questionTime--;
            updateQuestionTimer(questionTime);
            
            if (questionTime <= 0) {
                clearInterval(questionTimer);
                handleTimeout();
            }
        }, 1000);
        
        // فعال کردن دکمه ادامه پس از انتخاب پاسخ
        $('input[name="answer"]').change(function() {
            $('#nextBtn').prop('disabled', false);
        });
        
        // حذف دو گزینه
        $('#eliminateBtn').click(function() {
            if (confirm('آیا مایلید 50 داریک هزینه کنید تا 2 گزینه تصادفی حذف شوند؟')) {
                const correctOption = question.correct_option;
                let optionsToEliminate = [1, 2, 3, 4].filter(opt => opt != correctOption);
                
                // انتخاب تصادفی 2 گزینه غلط
                optionsToEliminate = shuffleArray(optionsToEliminate).slice(0, 2);
                
                // غیرفعال کردن گزینه‌های انتخاب شده
                optionsToEliminate.forEach(opt => {
                    $(`#option${opt}`).prop('disabled', true).parent().addClass('text-muted');
                });
                
                $(this).prop('disabled', true);
                
                // کسر هزینه از حساب کاربر
                $.ajax({
                    url: '/api/user/deduct_daric.php',
                    method: 'POST',
                    data: { amount: 50, description: 'حذف گزینه در کل کل' },
                    success: function(response) {
                        if (!response.success) {
                            alert(response.message);
                        }
                    }
                });
            }
        });
        
        // رفتن به سوال بعدی
        $('#nextBtn').click(function() {
            clearInterval(questionTimer);
            processAnswer(question, questionTime);
        });
    }
    
    // تابع پردازش پاسخ
    function processAnswer(question, timeLeft) {
        const selectedOption = $('input[name="answer"]:checked').val();
        let questionScore = 0;
        let timeFactor = 0;
        
        // محاسبه امتیاز بر اساس زمان پاسخگویی
        if (selectedOption == question.correct_option) {
            answeredQuestions++;
            
            if (timeLeft >= 8) timeFactor = 5; // 2 ثانیه اول
            else if (timeLeft >= 6) timeFactor = 4; // 4 ثانیه اول
            else if (timeLeft >= 4) timeFactor = 3; // 6 ثانیه اول
            else if (timeLeft >= 2) timeFactor = 2; // 8 ثانیه اول
            else timeFactor = 1; // 10 ثانیه اول
            
            questionScore = timeFactor;
            score += questionScore;
        }
        
        // نمایش پاسخ صحیح
        $('.options .form-check-input').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        if (selectedOption && selectedOption != question.correct_option) {
            $(`#option${selectedOption}`).parent().addClass('text-danger');
        }
        
        // نمایش نتیجه سوال
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
        
        const resultHtml = `
            <div class="alert ${selectedOption == question.correct_option ? 'alert-success' : 'alert-danger'} mt-3">
                ${selectedOption == question.correct_option ? 
                    `پاسخ صحیح! (+${questionScore} امتیاز)` : 
                    'پاسخ اشتباه! (0 امتیاز)'}
                <div class="mt-2">
                    <button class="btn btn-sm btn-orange" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `;
        
        $('#quizContainer .question').append(resultHtml);
    }
    
    // تابع پایان کل کل
    function endDuel() {
        clearInterval(timer);
        clearInterval(questionTimer);
        
        // ارسال نتایج به سرور
        $.ajax({
            url: '/api/duels/save_result.php',
            method: 'POST',
            data: {
                duel_id: <?= $duel['id'] ?>,
                team_id: <?= $team['id'] ?>,
                score: score,
                answered_questions: answeredQuestions
            },
            success: function(response) {
                const html = `
                    <div class="text-center py-5">
                        <h3 class="text-orange mb-4">کل کل به پایان رسید!</h3>
                        <div class="final-score mb-4">
                            <h1 class="display-1 ${score >= 70 ? 'text-success' : score >= 40 ? 'text-warning' : 'text-danger'}">
                                ${score}
                            </h1>
                            <p class="lead">امتیاز نهایی شما</p>
                        </div>
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-6">
                                <div class="card bg-dark">
                                    <div class="card-body">
                                        <p>پاسخ‌های صحیح: <strong>${Math.round(score / 5)} از 20</strong></p>
                                        <p>میانگین امتیاز اکیپ شما: <strong>${response.team_avg}</strong></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="/pages/team.php?id=<?= $team['id'] ?>" class="btn btn-purple">
                                مشاهده اکیپ
                            </a>
                            <a href="/pages/team_admin.php" class="btn btn-orange">
                                مدیریت اکیپ
                            </a>
                        </div>
                    </div>
                `;
                
                $('#quizContainer').html(html);
            }
        });
    }
    
    // تابع نمایش تایمر
    function updateTimer() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        $('#timer').text(`${minutes}:${seconds < 10 ? '0' + seconds : seconds}`);
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            endDuel();
        } else {
            timeLeft--;
        }
    }
    
    // تابع نمایش تایمر سوال
    function updateQuestionTimer(seconds) {
        const $timer = $('#timer');
        $timer.removeClass('bg-danger bg-warning');
        
        if (seconds <= 3) {
            $timer.addClass('bg-danger');
        } else if (seconds <= 6) {
            $timer.addClass('bg-warning');
        }
        
        $timer.text(`0:${seconds < 10 ? '0' + seconds : seconds}`);
    }
    
    // تابع زمان‌دهی پاسخ
    function handleTimeout() {
        const question = questions[currentQuestion];
        $('input[name="answer"]').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        $('#quizContainer').append(`
            <div class="alert alert-warning mt-3">
                زمان شما برای پاسخگویی به پایان رسید!
                <div class="mt-2">
                    <button class="btn btn-sm btn-purple" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `);
        
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
    }
    
    // تابع رفتن به سوال بعدی (برای استفاده در HTML)
    window.nextQuestion = function() {
        currentQuestion++;
        showQuestion(currentQuestion);
    };
    
    // تابع شروع آزمون
    $('#startQuiz').click(function() {
        quizStarted = true;
        showQuestion(0);
        
        // شروع تایمر کلی
        timer = setInterval(updateTimer, 1000);
    });
    
    // تابع تصادفی سازی آرایه
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});
</script>
<?php endif; ?>

<?php
require_once '../includes/footer.php';
?>