<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// دریافت اطلاعات کاربر
$user_stmt = $pdo->prepare("
    SELECT u.*, 
           (SELECT COUNT(*) FROM team_members WHERE user_id = u.id AND is_active = 1) as team_count
    FROM users u
    WHERE u.id = ?
");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();

if (!$user) {
    header("Location: /pages/dashboard.php?error=invalid_user");
    exit();
}

// دریافت اکیپ‌های کاربر
$teams_stmt = $pdo->prepare("
    SELECT t.id, t.name, t.logo, 
           (SELECT COUNT(*) FROM team_members WHERE team_id = t.id AND is_active = 1) as member_count
    FROM team_members tm
    JOIN teams t ON tm.team_id = t.id
    WHERE tm.user_id = ? AND tm.is_active = 1
");
$teams_stmt->execute([$user_id]);
$teams = $teams_stmt->fetchAll();

// دریافت آمار بازی‌های تمرینی
$practice_stats = $pdo->prepare("
    SELECT 
        COUNT(*) as total_games,
        AVG(score) as avg_score,
        MAX(score) as max_score,
        MIN(score) as min_score
    FROM practice_games 
    WHERE user_id = ?
")->execute([$user_id])->fetch();

// دریافت 10 بازی اخیر
$recent_games = $pdo->prepare("
    SELECT pg.score, pg.played_at, c.name as category_name
    FROM practice_games pg
    JOIN categories c ON pg.category_id = c.id
    WHERE pg.user_id = ?
    ORDER BY pg.played_at DESC
    LIMIT 10
")->execute([$user_id])->fetchAll();

$page_title = "پروفایل کاربر - " . $user['username'];
$active_page = "profile";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <!-- اطلاعات کاربر -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">اطلاعات کاربر</h5>
                </div>
                <div class="card-body text-center">
                    <div class="avatar mb-3">
                        <img src="/assets/images/default-avatar.png" class="rounded-circle" width="120" alt="آواتار">
                    </div>
                    <h4><?= $user['username'] ?></h4>
                    
                    <hr>
                    
                    <div class="user-stats">
                        <div class="d-flex justify-content-between">
                            <span>موجودی داریک:</span>
                            <span class="fw-bold text-orange"><?= number_format($user['daric_balance']) ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>تعداد اکیپ‌ها:</span>
                            <span class="fw-bold"><?= $user['team_count'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>تعداد بازی‌ها:</span>
                            <span class="fw-bold"><?= $practice_stats['total_games'] ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>میانگین امتیاز:</span>
                            <span class="fw-bold"><?= round($practice_stats['avg_score'], 1) ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- اکیپ‌های کاربر -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-orange text-white">
                    <h5 class="mb-0">اکیپ‌ها</h5>
                </div>
                <div class="card-body p-0">
                    <?php if (!empty($teams)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($teams as $team): ?>
                                <a href="/pages/team.php?id=<?= $team['id'] ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center">
                                        <img src="<?= $team['logo'] ? '/assets/images/teams/' . $team['logo'] : '/assets/images/default-team.png' ?>" 
                                             class="rounded-circle me-2" width="30" alt="<?= $team['name'] ?>">
                                        <span><?= $team['name'] ?></span>
                                    </div>
                                    <span class="badge bg-dark"><?= $team['member_count'] ?> عضو</span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-3">
                            <p class="text-muted">کاربر عضو هیچ اکیپی نیست</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <!-- بازی‌های اخیر -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">10 بازی اخیر</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>دسته بندی</th>
                                    <th>امتیاز</th>
                                    <th>تاریخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_games as $game): ?>
                                    <tr>
                                        <td><?= $game['category_name'] ?></td>
                                        <td><?= $game['score'] ?></td>
                                        <td><?= jdate('Y/m/d H:i', strtotime($game['played_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <?php if (empty($recent_games)): ?>
                                    <tr>
                                        <td colspan="3" class="text-center py-4">بازی‌ای انجام نشده است</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- آمار بازی‌ها -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">آمار بازی‌ها</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card bg-dark text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">بالاترین امتیاز</h6>
                                    <h3 class="mb-0 text-success"><?= $practice_stats['max_score'] ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="card bg-dark text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title">پایین‌ترین امتیاز</h6>
                                    <h3 class="mb-0 text-danger"><?= $practice_stats['min_score'] ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="/pages/practice.php" class="btn btn-orange">
                            شروع بازی جدید
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../includes/footer.php';
?>