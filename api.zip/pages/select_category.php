<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$type = isset($_GET['type']) ? $_GET['type'] : 'practice';
$error = isset($_GET['error']) ? $_GET['error'] : null;

// دریافت دسته بندی‌های فعال
$categories = $pdo->query("SELECT id, name, description FROM categories WHERE is_active = 1")->fetchAll();

$page_title = "انتخاب دسته بندی";
$active_page = $type;
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">
                        <?= $type === 'practice' ? 'آزمون تمرینی' : ($type === 'duel' ? 'کل کل' : 'چالش') ?>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($error === 'not_enough'): ?>
                        <div class="alert alert-danger">
                            <p>سوالات کافی در این دسته بندی موجود نیست. لطفاً دسته دیگری انتخاب کنید.</p>
                        </div>
                    <?php endif; ?>
                    
                    <h4 class="text-center mb-4">لطفاً یک دسته بندی انتخاب کنید:</h4>
                    
                    <div class="row">
                        <?php foreach ($categories as $category): ?>
                            <div class="col-md-6 mb-3">
                                <div class="card bg-dark h-100">
                                    <div class="card-body">
                                        <h5 class="card-title text-orange"><?= $category['name'] ?></h5>
                                        <p class="card-text text-muted"><?= $category['description'] ?></p>
                                        <a href="/pages/<?= $type ?>.php?category=<?= $category['id'] ?>" class="btn btn-sm btn-purple">
                                            انتخاب
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($type === 'practice'): ?>
                        <div class="text-center mt-4">
                            <a href="/pages/dashboard.php" class="btn btn-outline-light">
                                بازگشت به داشبورد
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../includes/footer.php';
?>