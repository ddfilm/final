<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// اگر دسته بندی انتخاب نشده باشد، به صفحه انتخاب دسته بندی هدایت شود
if (!isset($_GET['category'])) {
    header("Location: /pages/select_category.php?type=practice");
    exit();
}

$category_id = intval($_GET['category']);

// بررسی معتبر بودن دسته بندی
$category_stmt = $pdo->prepare("SELECT name FROM categories WHERE id = ? AND is_active = 1");
$category_stmt->execute([$category_id]);
$category = $category_stmt->fetch();

if (!$category) {
    header("Location: /pages/select_category.php?type=practice");
    exit();
}

// دریافت 20 سوال تصادفی از دسته بندی انتخاب شده
$questions_stmt = $pdo->prepare("
    SELECT id, question, option1, option2, option3, option4, correct_option 
    FROM questions 
    WHERE category_id = ? AND is_approved = 1
    ORDER BY RAND()
    LIMIT 20
");
$questions_stmt->execute([$category_id]);
$questions = $questions_stmt->fetchAll();

// اگر سوال کافی وجود نداشته باشد
if (count($questions) < 20) {
    header("Location: /pages/select_category.php?type=practice&error=not_enough");
    exit();
}

$page_title = "آزمون تمرینی - " . $category['name'];
$active_page = "practice";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">آزمون تمرینی - <?= $category['name'] ?></h5>
                    <div>
                        <span id="timer" class="badge bg-orange">20:00</span>
                        <span id="questionCounter" class="badge bg-dark">1/20</span>
                    </div>
                </div>
                <div class="card-body">
                    <div id="quizContainer">
                        <div class="text-center py-4">
                            <h4 class="text-orange mb-3">آماده شروع آزمون هستید؟</h4>
                            <p class="mb-4">این آزمون شامل 20 سوال از دسته بندی <?= $category['name'] ?> می‌باشد.</p>
                            <p class="mb-4">برای هر سوال 10 ثانیه زمان دارید. هرچه سریع‌تر پاسخ دهید، امتیاز بیشتری دریافت می‌کنید.</p>
                            <button id="startQuiz" class="btn btn-lg btn-purple">شروع آزمون</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    const questions = <?= json_encode($questions) ?>;
    let currentQuestion = 0;
    let score = 0;
    let quizStarted = false;
    let timer;
    let questionTimer;
    let timeLeft = 1200; // 20 دقیقه به ثانیه
    
    // تابع نمایش سوال
    function showQuestion(index) {
        if (index >= questions.length) {
            endQuiz();
            return;
        }
        
        const question = questions[index];
        $('#questionCounter').text((index + 1) + '/20');
        
        // ایجاد HTML سوال
        let html = `
            <div class="question" data-id="${question.id}">
                <h4 class="mb-4">${question.question}</h4>
                <div class="options">
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option1" value="1">
                        <label class="form-check-label" for="option1">${question.option1}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option2" value="2">
                        <label class="form-check-label" for="option2">${question.option2}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option3" value="3">
                        <label class="form-check-label" for="option3">${question.option3}</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="radio" name="answer" id="option4" value="4">
                        <label class="form-check-label" for="option4">${question.option4}</label>
                    </div>
                </div>
                <div class="d-flex justify-content-between mt-4">
                    <button id="eliminateBtn" class="btn btn-sm btn-outline-orange" data-cost="50">
                        حذف 2 گزینه (50 داریک)
                    </button>
                    <button id="nextBtn" class="btn btn-purple" disabled>ادامه</button>
                </div>
            </div>
        `;
        
        $('#quizContainer').html(html);
        
        // ریست تایمر سوال
        clearInterval(questionTimer);
        let questionTime = 10;
        updateQuestionTimer(questionTime);
        
        questionTimer = setInterval(function() {
            questionTime--;
            updateQuestionTimer(questionTime);
            
            if (questionTime <= 0) {
                clearInterval(questionTimer);
                handleTimeout();
            }
        }, 1000);
        
        // فعال کردن دکمه ادامه پس از انتخاب پاسخ
        $('input[name="answer"]').change(function() {
            $('#nextBtn').prop('disabled', false);
        });
        
        // حذف دو گزینه
        $('#eliminateBtn').click(function() {
            if (confirm('آیا مایلید 50 داریک هزینه کنید تا 2 گزینه تصادفی حذف شوند؟')) {
                const correctOption = question.correct_option;
                let optionsToEliminate = [1, 2, 3, 4].filter(opt => opt != correctOption);
                
                // انتخاب تصادفی 2 گزینه غلط
                optionsToEliminate = shuffleArray(optionsToEliminate).slice(0, 2);
                
                // غیرفعال کردن گزینه‌های انتخاب شده
                optionsToEliminate.forEach(opt => {
                    $(`#option${opt}`).prop('disabled', true).parent().addClass('text-muted');
                });
                
                $(this).prop('disabled', true);
                
                // کسر هزینه از حساب کاربر
                $.ajax({
                    url: '/api/user/deduct_daric.php',
                    method: 'POST',
                    data: { amount: 50, description: 'حذف گزینه در آزمون تمرینی' },
                    success: function(response) {
                        if (!response.success) {
                            alert(response.message);
                        }
                    }
                });
            }
        });
        
        // رفتن به سوال بعدی
        $('#nextBtn').click(function() {
            clearInterval(questionTimer);
            processAnswer(question, questionTime);
        });
    }
    
    // تابع پردازش پاسخ
    function processAnswer(question, timeLeft) {
        const selectedOption = $('input[name="answer"]:checked').val();
        let questionScore = 0;
        let timeFactor = 0;
        
        // محاسبه امتیاز بر اساس زمان پاسخگویی
        if (selectedOption == question.correct_option) {
            if (timeLeft >= 8) timeFactor = 5; // 2 ثانیه اول
            else if (timeLeft >= 6) timeFactor = 4; // 4 ثانیه اول
            else if (timeLeft >= 4) timeFactor = 3; // 6 ثانیه اول
            else if (timeLeft >= 2) timeFactor = 2; // 8 ثانیه اول
            else timeFactor = 1; // 10 ثانیه اول
            
            questionScore = timeFactor;
            score += questionScore;
        }
        
        // نمایش پاسخ صحیح
        $('.options .form-check-input').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        if (selectedOption && selectedOption != question.correct_option) {
            $(`#option${selectedOption}`).parent().addClass('text-danger');
        }
        
        // نمایش نتیجه سوال
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
        
        const resultHtml = `
            <div class="alert ${selectedOption == question.correct_option ? 'alert-success' : 'alert-danger'} mt-3">
                ${selectedOption == question.correct_option ? 
                    `پاسخ صحیح! (+${questionScore} امتیاز)` : 
                    'پاسخ اشتباه! (0 امتیاز)'}
                <div class="mt-2">
                    <button class="btn btn-sm btn-purple" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `;
        
        $('#quizContainer .question').append(resultHtml);
    }
    
    // تابع پایان آزمون
    function endQuiz() {
        clearInterval(timer);
        clearInterval(questionTimer);
        
        // محاسبه نمره نهایی (از 100)
        const finalScore = Math.round((score / 100) * 100);
        
        // ارسال نتایج به سرور
        $.ajax({
            url: '/api/practice/save_result.php',
            method: 'POST',
            data: {
                category_id: <?= $category_id ?>,
                score: finalScore,
                total_questions: 20,
                correct_answers: Math.round(score / 5) // چون هر پاسخ صحیح 1 تا 5 امتیاز دارد
            },
            success: function(response) {
                const html = `
                    <div class="text-center py-5">
                        <h3 class="text-orange mb-4">آزمون به پایان رسید!</h3>
                        <div class="final-score mb-4">
                            <h1 class="display-1 ${finalScore >= 70 ? 'text-success' : finalScore >= 40 ? 'text-warning' : 'text-danger'}">
                                ${finalScore}
                            </h1>
                            <p class="lead">از 100</p>
                        </div>
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-6">
                                <div class="card bg-dark">
                                    <div class="card-body">
                                        <p>امتیاز کسب شده: <strong>${score}</strong></p>
                                        <p>پاسخ‌های صحیح: <strong>${Math.round(score / 5)} از 20</strong></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="/pages/practice.php?category=<?= $category_id ?>" class="btn btn-purple">
                                آزمون مجدد
                            </a>
                            <a href="/pages/select_category.php?type=practice" class="btn btn-orange">
                                انتخاب دسته دیگر
                            </a>
                            <a href="/pages/dashboard.php" class="btn btn-outline-light">
                                بازگشت به داشبورد
                            </a>
                        </div>
                    </div>
                `;
                
                $('#quizContainer').html(html);
            }
        });
    }
    
    // تابع نمایش تایمر
    function updateTimer() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        $('#timer').text(`${minutes}:${seconds < 10 ? '0' + seconds : seconds}`);
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            endQuiz();
        } else {
            timeLeft--;
        }
    }
    
    // تابع نمایش تایمر سوال
    function updateQuestionTimer(seconds) {
        const $timer = $('#timer');
        $timer.removeClass('bg-danger bg-warning');
        
        if (seconds <= 3) {
            $timer.addClass('bg-danger');
        } else if (seconds <= 6) {
            $timer.addClass('bg-warning');
        }
        
        $timer.text(`0:${seconds < 10 ? '0' + seconds : seconds}`);
    }
    
    // تابع زمان‌دهی پاسخ
    function handleTimeout() {
        const question = questions[currentQuestion];
        $('input[name="answer"]').prop('disabled', true);
        $(`#option${question.correct_option}`).parent().addClass('text-success');
        
        $('#quizContainer').append(`
            <div class="alert alert-warning mt-3">
                زمان شما برای پاسخگویی به پایان رسید!
                <div class="mt-2">
                    <button class="btn btn-sm btn-purple" onclick="nextQuestion()">سوال بعدی</button>
                </div>
            </div>
        `);
        
        $('#nextBtn').remove();
        $('#eliminateBtn').remove();
    }
    
    // تابع رفتن به سوال بعدی (برای استفاده در HTML)
    window.nextQuestion = function() {
        currentQuestion++;
        showQuestion(currentQuestion);
    };
    
    // تابع شروع آزمون
    $('#startQuiz').click(function() {
        quizStarted = true;
        showQuestion(0);
        
        // شروع تایمر کلی
        timer = setInterval(updateTimer, 1000);
    });
    
    // تابع تصادفی سازی آرایه
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
});
</script>

<?php
require_once '../includes/footer.php';
?>