<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین کرده باشد، به داشبورد هدایت شود
if (isset($_SESSION['user_id'])) {
    header("Location: /pages/dashboard.php");
    exit();
}

$page_title = "ورود/ثبت نام - داریک تست";
$active_page = "login";
require_once '../includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="text-center mb-5">
                <img src="/assets/images/logo.png" alt="Daric Test" class="logo mb-3">
                <h1 class="text-purple">داریک تست</h1>
                <p class="text-muted">مسابقات آنلاین اطلاعات عمومی</p>
            </div>

            <ul class="nav nav-tabs justify-content-center mb-4" id="authTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login" type="button" role="tab">ورود</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="register-tab" data-bs-toggle="tab" data-bs-target="#register" type="button" role="tab">ثبت نام</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="recover-tab" data-bs-toggle="tab" data-bs-target="#recover" type="button" role="tab">بازیابی</button>
                </li>
            </ul>

            <div class="tab-content" id="authTabsContent">
                <!-- تب ورود -->
                <div class="tab-pane fade show active" id="login" role="tabpanel">
                    <div class="card shadow-sm">
                        <div class="card-body p-4">
                            <form id="loginForm" method="post">
                                <div class="mb-3">
                                    <label for="loginUsername" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="loginUsername" name="username" required>
                                </div>
                                <div class="mb-3">
                                    <label for="loginPassword" class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" id="loginPassword" name="password" required>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-purple">ورود به حساب</button>
                                </div>
                            </form>
                            <div id="loginMessage" class="mt-3"></div>
                        </div>
                    </div>
                </div>

                <!-- تب ثبت نام -->
                <div class="tab-pane fade" id="register" role="tabpanel">
                    <div class="card shadow-sm">
                        <div class="card-body p-4">
                            <form id="registerForm" method="post">
                                <div class="mb-3">
                                    <label for="registerUsername" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="registerUsername" name="username" pattern="[a-zA-Z0-9]+" required>
                                    <small class="form-text text-muted">فقط حروف انگلیسی و اعداد مجاز است</small>
                                    <div id="usernameCheck" class="mt-1"></div>
                                </div>
                                <div class="mb-3">
                                    <label for="registerPassword" class="form-label">رمز عبور</label>
                                    <input type="password" class="form-control" id="registerPassword" name="password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="registerPasswordConfirm" class="form-label">تکرار رمز عبور</label>
                                    <input type="password" class="form-control" id="registerPasswordConfirm" name="password_confirm" required>
                                </div>
                                
                                <hr class="my-4">
                                
                                <p class="text-center text-orange">لطفاً به سوالات زیر پاسخ دهید. این پاسخ‌ها تنها راه بازیابی حساب شما خواهند بود.</p>
                                
                                <div class="mb-3">
                                    <label class="form-label">رنگ مورد علاقه شما چیست؟</label>
                                    <select class="form-select" name="security_color" required>
                                        <option value="" selected disabled>انتخاب کنید</option>
                                        <option value="قرمز">قرمز</option>
                                        <option value="آبی">آبی</option>
                                        <option value="سبز">سبز</option>
                                        <option value="زرد">زرد</option>
                                        <option value="بنفش">بنفش</option>
                                        <option value="نارنجی">نارنجی</option>
                                        <option value="صورتی">صورتی</option>
                                        <option value="قهوه‌ای">قهوه‌ای</option>
                                        <option value="مشکی">مشکی</option>
                                        <option value="سفید">سفید</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">گل مورد علاقه شما چیست؟</label>
                                    <select class="form-select" name="security_flower" required>
                                        <option value="" selected disabled>انتخاب کنید</option>
                                        <option value="رز">رز</option>
                                        <option value="لاله">لاله</option>
                                        <option value="نرگس">نرگس</option>
                                        <option value="زنبق">زنبق</option>
                                        <option value="میخک">میخک</option>
                                        <option value="آفتابگردان">آفتابگردان</option>
                                        <option value="ارکیده">ارکیده</option>
                                        <option value="یاس">یاس</option>
                                        <option value="شقایق">شقایق</option>
                                        <option value="مریم">مریم</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">شهر مورد علاقه شما چیست؟</label>
                                    <select class="form-select" name="security_city" required>
                                        <option value="" selected disabled>انتخاب کنید</option>
                                        <option value="تهران">تهران</option>
                                        <option value="مشهد">مشهد</option>
                                        <option value="اصفهان">اصفهان</option>
                                        <option value="شیراز">شیراز</option>
                                        <option value="تبریز">تبریز</option>
                                        <option value="اهواز">اهواز</option>
                                        <option value="رشت">رشت</option>
                                        <option value="کرمان">کرمان</option>
                                        <option value="یزد">یزد</option>
                                        <option value="ارومیه">ارومیه</option>
                                    </select>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-orange">ثبت نام</button>
                                </div>
                            </form>
                            <div id="registerMessage" class="mt-3"></div>
                        </div>
                    </div>
                </div>

                <!-- تب بازیابی -->
                <div class="tab-pane fade" id="recover" role="tabpanel">
                    <div class="card shadow-sm">
                        <div class="card-body p-4">
                            <form id="recoverForm" method="post">
                                <div class="mb-3">
                                    <label for="recoverUsername" class="form-label">نام کاربری</label>
                                    <input type="text" class="form-control" id="recoverUsername" name="username" required>
                                </div>
                                
                                <div id="securityQuestions" class="d-none">
                                    <div class="mb-3">
                                        <label class="form-label">رنگ مورد علاقه شما چیست؟</label>
                                        <select class="form-select" name="recover_color" required>
                                            <option value="" selected disabled>انتخاب کنید</option>
                                            <option value="قرمز">قرمز</option>
                                            <option value="آبی">آبی</option>
                                            <option value="سبز">سبز</option>
                                            <option value="زرد">زرد</option>
                                            <option value="بنفش">بنفش</option>
                                            <option value="نارنجی">نارنجی</option>
                                            <option value="صورتی">صورتی</option>
                                            <option value="قهوه‌ای">قهوه‌ای</option>
                                            <option value="مشکی">مشکی</option>
                                            <option value="سفید">سفید</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">گل مورد علاقه شما چیست؟</label>
                                        <select class="form-select" name="recover_flower" required>
                                            <option value="" selected disabled>انتخاب کنید</option>
                                            <option value="رز">رز</option>
                                            <option value="لاله">لاله</option>
                                            <option value="نرگس">نرگس</option>
                                            <option value="زنبق">زنبق</option>
                                            <option value="میخک">میخک</option>
                                            <option value="آفتابگردان">آفتابگردان</option>
                                            <option value="ارکیده">ارکیده</option>
                                            <option value="یاس">یاس</option>
                                            <option value="شقایق">شقایق</option>
                                            <option value="مریم">مریم</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">شهر مورد علاقه شما چیست؟</label>
                                        <select class="form-select" name="recover_city" required>
                                            <option value="" selected disabled>انتخاب کنید</option>
                                            <option value="تهران">تهران</option>
                                            <option value="مشهد">مشهد</option>
                                            <option value="اصفهان">اصفهان</option>
                                            <option value="شیراز">شیراز</option>
                                            <option value="تبریز">تبریز</option>
                                            <option value="اهواز">اهواز</option>
                                            <option value="رشت">رشت</option>
                                            <option value="کرمان">کرمان</option>
                                            <option value="یزد">یزد</option>
                                            <option value="ارومیه">ارومیه</option>
                                        </select>
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-purple">تایید پاسخ‌ها</button>
                                    </div>
                                </div>
                            </form>
                            
                            <div id="recoverMessage" class="mt-3"></div>
                            
                            <div id="passwordResult" class="d-none">
                                <div class="alert alert-success">
                                    <h5 class="alert-heading">رمز عبور شما:</h5>
                                    <p id="userPassword" class="mb-0 fw-bold"></p>
                                </div>
                                <a href="/pages/login.php" class="btn btn-orange">ورود به حساب</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // بررسی نام کاربری در حین تایپ
    $('#registerUsername').on('input', function() {
        const username = $(this).val();
        if (username.length >= 3) {
            $.ajax({
                url: '/api/auth/check_username.php',
                method: 'POST',
                data: { username: username },
                success: function(response) {
                    if (response.available) {
                        $('#usernameCheck').html('<span class="text-success">این نام کاربری قابل استفاده است</span>');
                    } else {
                        $('#usernameCheck').html('<span class="text-danger">این نام کاربری قبلاً ثبت شده است</span>');
                    }
                }
            });
        }
    });
    
    // ارسال فرم ورود
    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/auth/login.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    window.location.href = '/pages/dashboard.php';
                } else {
                    $('#loginMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // ارسال فرم ثبت نام
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/auth/register.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#registerMessage').html('<div class="alert alert-success">ثبت نام با موفقیت انجام شد. لطفاً وارد شوید.</div>');
                    $('#registerForm')[0].reset();
                    $('#authTabs .nav-link').removeClass('active');
                    $('#login-tab').addClass('active');
                    $('.tab-pane').removeClass('show active');
                    $('#login').addClass('show active');
                } else {
                    $('#registerMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // بررسی نام کاربری برای بازیابی
    $('#recoverUsername').on('blur', function() {
        const username = $(this).val();
        if (username.length >= 3) {
            $.ajax({
                url: '/api/auth/check_recovery.php',
                method: 'POST',
                data: { username: username },
                success: function(response) {
                    if (response.exists) {
                        $('#securityQuestions').removeClass('d-none');
                    } else {
                        $('#recoverMessage').html('<div class="alert alert-danger">نام کاربری یافت نشد</div>');
                    }
                }
            });
        }
    });
    
    // ارسال فرم بازیابی
    $('#recoverForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: '/api/auth/recover.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    $('#securityQuestions').addClass('d-none');
                    $('#recoverForm').addClass('d-none');
                    $('#userPassword').text(response.password);
                    $('#passwordResult').removeClass('d-none');
                } else {
                    $('#recoverMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
});
</script>

<?php
require_once '../includes/footer.php';
?>