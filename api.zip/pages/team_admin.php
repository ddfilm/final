<?php
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

session_start();

// اگر کاربر لاگین نکرده باشد، به صفحه ورود هدایت شود
if (!isset($_SESSION['user_id'])) {
    header("Location: /pages/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// بررسی آیا کاربر ادمین اکیپ است یا نه
$team_stmt = $pdo->prepare("
    SELECT t.id, t.name, t.logo, t.admin_id, 
           COUNT(tm.user_id) as member_count
    FROM teams t
    LEFT JOIN team_members tm ON t.id = tm.team_id AND tm.is_active = 1
    WHERE t.admin_id = ?
    GROUP BY t.id
");
$team_stmt->execute([$user_id]);
$team = $team_stmt->fetch();

if (!$team) {
    header("Location: /pages/dashboard.php?error=not_admin");
    exit();
}

// دریافت اعضای اکیپ
$members_stmt = $pdo->prepare("
    SELECT u.id, u.username, u.daric_balance, 
           (SELECT COUNT(*) FROM practice_games WHERE user_id = u.id) as games_played,
           (SELECT AVG(score) FROM practice_games WHERE user_id = u.id) as avg_score
    FROM team_members tm
    JOIN users u ON tm.user_id = u.id
    WHERE tm.team_id = ? AND tm.is_active = 1
    ORDER BY u.daric_balance DESC
");
$members_stmt->execute([$team['id']]);
$members = $members_stmt->fetchAll();

// دریافت درخواست‌های کل کل
$duels_stmt = $pdo->prepare("
    SELECT d.id, t.name as team_name, d.status, d.created_at, 
           d.cost, d.team1_score, d.team2_score
    FROM duels d
    JOIN teams t ON d.team1_id = t.id OR d.team2_id = t.id
    WHERE (d.team1_id = ? OR d.team2_id = ?) AND t.id != ?
    ORDER BY d.created_at DESC
");
$duels_stmt->execute([$team['id'], $team['id'], $team['id']]);
$duels = $duels_stmt->fetchAll();

$page_title = "مدیریت اکیپ - " . $team['name'];
$active_page = "team_admin";
require_once '../includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <!-- اطلاعات اکیپ -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">اطلاعات اکیپ</h5>
                </div>
                <div class="card-body text-center">
                    <img src="<?= $team['logo'] ? '/assets/images/teams/' . $team['logo'] : '/assets/images/default-team.png' ?>" 
                         class="rounded-circle mb-3" width="120" alt="لوگوی اکیپ">
                    <h4 class="text-orange"><?= $team['name'] ?></h4>
                    <p class="text-muted">تعداد اعضا: <?= $team['member_count'] ?> از 20</p>
                    
                    <hr>
                    
                    <div class="d-grid gap-2">
                        <button class="btn btn-orange" data-bs-toggle="modal" data-bs-target="#inviteMemberModal">
                            دعوت عضو جدید
                        </button>
                        <button class="btn btn-outline-purple" data-bs-toggle="modal" data-bs-target="#editTeamModal">
                            ویرایش اکیپ
                        </button>
                        <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#leaveTeamModal">
                            انحلال اکیپ
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- جستجوی اکیپ‌ها -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0">جستجوی اکیپ</h5>
                </div>
                <div class="card-body">
                    <form id="searchTeamForm">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="نام اکیپ" name="team_name">
                            <button class="btn btn-purple" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                    <div id="teamSearchResults" class="mt-3"></div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <!-- اعضای اکیپ -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-orange text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">اعضای اکیپ</h5>
                    <span><?= $team['member_count'] ?> عضو</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>نام کاربری</th>
                                    <th>موجودی داریک</th>
                                    <th>تعداد بازی‌ها</th>
                                    <th>میانگین امتیاز</th>
                                    <th>عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($members as $member): ?>
                                    <tr>
                                        <td>
                                            <a href="/pages/user_profile.php?id=<?= $member['id'] ?>" class="text-white">
                                                <?= $member['username'] ?>
                                            </a>
                                            <?php if ($member['id'] == $team['admin_id']): ?>
                                                <span class="badge bg-purple">ادمین</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= number_format($member['daric_balance']) ?></td>
                                        <td><?= $member['games_played'] ?></td>
                                        <td><?= round($member['avg_score'], 1) ?></td>
                                        <td>
                                            <?php if ($member['id'] != $team['admin_id']): ?>
                                                <button class="btn btn-sm btn-outline-danger kick-member" 
                                                        data-user-id="<?= $member['id'] ?>" 
                                                        data-username="<?= $member['username'] ?>">
                                                    اخراج
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- درخواست‌های کل کل -->
            <div class="card shadow-sm">
                <div class="card-header bg-purple text-white">
                    <h5 class="mb-0">درخواست‌های کل کل</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($duels)): ?>
                        <div class="alert alert-info">
                            هیچ درخواست کل کلی وجود ندارد.
                        </div>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($duels as $duel): ?>
                                <div class="list-group-item list-group-item-dark">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1"><?= $duel['team_name'] ?></h6>
                                            <small class="text-muted">
                                                <?= jdate('Y/m/d H:i', strtotime($duel['created_at'])) ?>
                                                • هزینه: <?= number_format($duel['cost']) ?> داریک
                                            </small>
                                        </div>
                                        <div>
                                            <?php if ($duel['status'] == 'pending'): ?>
                                                <button class="btn btn-sm btn-success accept-duel" 
                                                        data-duel-id="<?= $duel['id'] ?>">
                                                    قبول
                                                </button>
                                                <button class="btn btn-sm btn-danger reject-duel" 
                                                        data-duel-id="<?= $duel['id'] ?>">
                                                    رد
                                                </button>
                                            <?php elseif ($duel['status'] == 'accepted'): ?>
                                                <span class="badge bg-info">در حال برگزاری</span>
                                            <?php elseif ($duel['status'] == 'completed'): ?>
                                                <span class="badge <?= $duel['team1_score'] > $duel['team2_score'] ? 'bg-success' : 'bg-danger' ?>">
                                                    <?= $duel['team1_score'] > $duel['team2_score'] ? 'برنده' : 'بازنده' ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">رد شده</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="d-grid gap-2 mt-4">
                        <button class="btn btn-orange" data-bs-toggle="modal" data-bs-target="#newDuelModal">
                            ارسال درخواست کل کل جدید
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- مودال دعوت عضو جدید -->
<div class="modal fade" id="inviteMemberModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-orange text-white">
                <h5 class="modal-title">دعوت عضو جدید</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="inviteMemberForm">
                    <div class="mb-3">
                        <label class="form-label">نام کاربری</label>
                        <input type="text" class="form-control" name="username" required>
                        <small class="form-text text-muted">نام کاربری شخصی که می‌خواهید دعوت کنید</small>
                    </div>
                    <div class="alert alert-info">
                        <p class="mb-0">برای هر دعوت، 50 داریک از حساب شما کسر خواهد شد.</p>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-purple">ارسال دعوتنامه</button>
                    </div>
                </form>
                <div id="inviteMessage" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<!-- مودال ویرایش اکیپ -->
<div class="modal fade" id="editTeamModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-purple text-white">
                <h5 class="modal-title">ویرایش اکیپ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editTeamForm">
                    <div class="mb-3">
                        <label class="form-label">نام اکیپ</label>
                        <input type="text" class="form-control" name="team_name" value="<?= $team['name'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">لوگوی اکیپ (اختیاری)</label>
                        <input type="file" class="form-control" name="team_logo" accept="image/*">
                        <small class="form-text text-muted">تصویر مربع با حداکثر سایز 512x512 پیکسل</small>
                    </div>
                    <div class="alert alert-info">
                        <p class="mb-0">برای تغییر لوگو، 100 داریک از حساب شما کسر خواهد شد.</p>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-orange">ذخیره تغییرات</button>
                    </div>
                </form>
                <div id="editTeamMessage" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<!-- مودال انحلال اکیپ -->
<div class="modal fade" id="leaveTeamModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">انحلال اکیپ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger">
                    <h5 class="alert-heading">هشدار!</h5>
                    <p class="mb-0">آیا مطمئن هستید که می‌خواهید اکیپ را منحل کنید؟ این عمل غیرقابل برگشت است و تمام اعضا از اکیپ خارج خواهند شد.</p>
                </div>
                <form id="leaveTeamForm">
                    <div class="mb-3">
                        <label class="form-label">برای تایید، رمز عبور خود را وارد کنید</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-danger">تایید انحلال اکیپ</button>
                    </div>
                </form>
                <div id="leaveTeamMessage" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<!-- مودال درخواست کل کل جدید -->
<div class="modal fade" id="newDuelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header bg-orange text-white">
                <h5 class="modal-title">درخواست کل کل جدید</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="newDuelForm">
                    <div class="mb-3">
                        <label class="form-label">اکیپ مقابل</label>
                        <input type="text" class="form-control" id="opponentTeam" name="opponent_team" required>
                        <small class="form-text text-muted">نام یا شناسه اکیپ مقابل را وارد کنید</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">هزینه کل کل</label>
                        <input type="number" class="form-control" name="cost" min="100" max="1000" value="200" required>
                        <small class="form-text text-muted">مبلغی که هر عضو از هر دو اکیپ باید پرداخت کند (100 تا 1000 داریک)</small>
                    </div>
                    <div class="alert alert-info">
                        <p class="mb-0">هزینه کل کل به طور مساوی بین تمام اعضای دو اکیپ تقسیم خواهد شد.</p>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-purple">ارسال درخواست</button>
                    </div>
                </form>
                <div id="newDuelMessage" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // جستجوی اکیپ
    $('#searchTeamForm').on('submit', function(e) {
        e.preventDefault();
        const teamName = $('input[name="team_name"]').val();
        
        if (teamName.length < 2) {
            $('#teamSearchResults').html('<div class="alert alert-warning">لطفاً حداقل 2 کاراکتر وارد کنید</div>');
            return;
        }
        
        $.ajax({
            url: '/api/teams/search.php',
            method: 'GET',
            data: { name: teamName, exclude: <?= $team['id'] ?> },
            success: function(response) {
                if (response.length > 0) {
                    let html = '<div class="list-group">';
                    response.forEach(team => {
                        html += `
                            <div class="list-group-item list-group-item-dark d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">${team.name}</h6>
                                    <small class="text-muted">${team.member_count} عضو</small>
                                </div>
                                <button class="btn btn-sm btn-orange send-duel" 
                                        data-team-id="${team.id}" 
                                        data-team-name="${team.name}">
                                    ارسال درخواست کل کل
                                </button>
                            </div>
                        `;
                    });
                    html += '</div>';
                    $('#teamSearchResults').html(html);
                } else {
                    $('#teamSearchResults').html('<div class="alert alert-info">اکیپی با این نام یافت نشد</div>');
                }
            }
        });
    });
    
    // ارسال دعوتنامه به عضو جدید
    $('#inviteMemberForm').on('submit', function(e) {
        e.preventDefault();
        const username = $('input[name="username"]').val();
        
        $.ajax({
            url: '/api/teams/invite.php',
            method: 'POST',
            data: { username: username, team_id: <?= $team['id'] ?> },
            success: function(response) {
                if (response.success) {
                    $('#inviteMessage').html('<div class="alert alert-success">دعوتنامه با موفقیت ارسال شد</div>');
                    $('#inviteMemberForm')[0].reset();
                    setTimeout(() => {
                        $('#inviteMemberModal').modal('hide');
                        location.reload();
                    }, 1500);
                } else {
                    $('#inviteMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // ویرایش اطلاعات اکیپ
    $('#editTeamForm').on('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('team_id', <?= $team['id'] ?>);
        
        $.ajax({
            url: '/api/teams/update.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    $('#editTeamMessage').html('<div class="alert alert-success">اطلاعات اکیپ با موفقیت به‌روزرسانی شد</div>');
                    setTimeout(() => {
                        $('#editTeamModal').modal('hide');
                        location.reload();
                    }, 1500);
                } else {
                    $('#editTeamMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // انحلال اکیپ
    $('#leaveTeamForm').on('submit', function(e) {
        e.preventDefault();
        const password = $('input[name="password"]').val();
        
        $.ajax({
            url: '/api/teams/disband.php',
            method: 'POST',
            data: { 
                team_id: <?= $team['id'] ?>,
                password: password 
            },
            success: function(response) {
                if (response.success) {
                    $('#leaveTeamMessage').html('<div class="alert alert-success">اکیپ با موفقیت منحل شد</div>');
                    setTimeout(() => {
                        window.location.href = '/pages/dashboard.php';
                    }, 1500);
                } else {
                    $('#leaveTeamMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // ارسال درخواست کل کل
    $('#newDuelForm').on('submit', function(e) {
        e.preventDefault();
        const opponentTeam = $('input[name="opponent_team"]').val();
        const cost = $('input[name="cost"]').val();
        
        $.ajax({
            url: '/api/duels/create.php',
            method: 'POST',
            data: { 
                team1_id: <?= $team['id'] ?>,
                opponent: opponentTeam,
                cost: cost 
            },
            success: function(response) {
                if (response.success) {
                    $('#newDuelMessage').html('<div class="alert alert-success">درخواست کل کل با موفقیت ارسال شد</div>');
                    $('#newDuelForm')[0].reset();
                    setTimeout(() => {
                        $('#newDuelModal').modal('hide');
                        location.reload();
                    }, 1500);
                } else {
                    $('#newDuelMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            }
        });
    });
    
    // قبول درخواست کل کل
    $(document).on('click', '.accept-duel', function() {
        const duelId = $(this).data('duel-id');
        
        if (confirm('آیا مطمئن هستید که می‌خواهید این درخواست کل کل را قبول کنید؟')) {
            $.ajax({
                url: '/api/duels/accept.php',
                method: 'POST',
                data: { duel_id: duelId },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.message);
                    }
                }
            });
        }
    });
    
    // رد درخواست کل کل
    $(document).on('click', '.reject-duel', function() {
        const duelId = $(this).data('duel-id');
        
        if (confirm('آیا مطمئن هستید که می‌خواهید این درخواست کل کل را رد کنید؟')) {
            $.ajax({
                url: '/api/duels/reject.php',
                method: 'POST',
                data: { duel_id: duelId },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.message);
                    }
                }
            });
        }
    });
    
    // اخراج عضو از اکیپ
    $(document).on('click', '.kick-member', function() {
        const userId = $(this).data('user-id');
        const username = $(this).data('username');
        
        if (confirm(`آیا مطمئن هستید که می‌خواهید کاربر ${username} را از اکیپ اخراج کنید؟`)) {
            $.ajax({
                url: '/api/teams/kick.php',
                method: 'POST',
                data: { 
                    team_id: <?= $team['id'] ?>,
                    user_id: userId 
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.message);
                    }
                }
            });
        }
    });
});
</script>

<?php
require_once '../includes/footer.php';
?>